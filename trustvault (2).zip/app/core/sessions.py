"""
TrustVault Server-Side Session Management
Issues cryptographically secure random session tokens, hashes them for DB storage,
and validates session state against authoritative database records on every request.
Supports HttpOnly cookies, Authorization Bearer headers, and X-Session-Token headers
to guarantee resilient session persistence across iframes, proxies, and API clients.
"""
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple
from fastapi import Request, HTTPException, status, Depends
from sqlalchemy.orm import Session
from app.core.config import SESSION_COOKIE_NAME, SESSION_EXPIRE_SECONDS
from app.core.security import generate_secure_token, hash_token
from app.database.session import get_db
from app.models.session import UserSession
from app.models.user import User


class SessionManager:
    @staticmethod
    def create_session(
        db: Session,
        user_id: str,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> Tuple[str, UserSession]:
        """
        Creates a new server-side session.
        Returns: (raw_session_token, db_session)
        """
        raw_token = generate_secure_token(48)
        token_hash = hash_token(raw_token)
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(seconds=SESSION_EXPIRE_SECONDS)

        session_obj = UserSession(
            user_id=user_id,
            session_token_hash=token_hash,
            is_active=True,
            created_at=now,
            expires_at=expires_at,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        db.add(session_obj)
        db.commit()
        db.refresh(session_obj)
        return raw_token, session_obj

    @staticmethod
    def validate_session(db: Session, raw_token: str) -> Optional[Tuple[User, UserSession]]:
        """
        Validates raw token against active, non-expired database session.
        Ensures user account is active.
        Extends session expiration on activity (rolling session).
        """
        if not raw_token:
            return None

        token_hash = hash_token(raw_token.strip())
        now = datetime.now(timezone.utc)

        db_session = (
            db.query(UserSession)
            .filter(
                UserSession.session_token_hash == token_hash,
                UserSession.is_active == True,
                UserSession.expires_at > now,
            )
            .first()
        )

        if not db_session:
            return None

        user = db.query(User).filter(User.id == db_session.user_id).first()
        if not user or not user.is_active:
            # If user was deactivated, invalidate session immediately
            db_session.is_active = False
            db.commit()
            return None

        # Rolling session: auto-extend if within 12 hours of expiration
        try:
            time_left = db_session.expires_at - now
            if time_left < timedelta(hours=12):
                db_session.expires_at = now + timedelta(seconds=SESSION_EXPIRE_SECONDS)
                db.commit()
        except Exception:
            pass

        return user, db_session

    @staticmethod
    def invalidate_session(db: Session, raw_token: str) -> bool:
        """Invalidate an active session by token."""
        if not raw_token:
            return False
        token_hash = hash_token(raw_token.strip())
        session_obj = db.query(UserSession).filter(UserSession.session_token_hash == token_hash).first()
        if session_obj:
            session_obj.is_active = False
            db.commit()
            return True
        return False

    @staticmethod
    def invalidate_all_user_sessions(db: Session, user_id: str) -> int:
        """Invalidate all active sessions for a user (e.g., on password reset or account deactivation)."""
        count = (
            db.query(UserSession)
            .filter(UserSession.user_id == user_id, UserSession.is_active == True)
            .update({"is_active": False})
        )
        db.commit()
        return count


def get_current_user(
    request: Request,
    db: Session = Depends(get_db)
) -> User:
    """
    Dependency that enforces valid authenticated identity on every protected endpoint.
    Extracts session token from:
    1. Header: X-Session-Token
    2. Header: Authorization: Bearer <token>
    3. Cookie: tv_session
    4. Query parameter: ?token=... (for direct browser file downloads in iframes)
    """
    token: Optional[str] = None

    # 1. Custom header
    custom_header = request.headers.get("X-Session-Token")
    if custom_header:
        token = custom_header.strip()

    # 2. Bearer authorization header
    if not token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ", 1)[1].strip()

    # 3. Cookie fallback
    if not token:
        token = request.cookies.get(SESSION_COOKIE_NAME)

    # 4. Query param fallback (for direct browser download links)
    if not token:
        token = request.query_params.get("session_token") or request.query_params.get("token")

    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required: No active session."
        )

    result = SessionManager.validate_session(db, token)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session invalid or expired. Please log in again."
        )

    user, _ = result
    return user


def get_current_admin(
    current_user: User = Depends(get_current_user)
) -> User:
    """Dependency that enforces Administrator role."""
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrative privileges required."
        )
    return current_user
