"""
Unit tests for file validation and storage security
"""
from app.services.storage_service import validate_file_content, sanitize_filename


def test_sanitize_filename():
    assert sanitize_filename("../../../etc/passwd") == "passwd"
    assert sanitize_filename("..\\..\\windows\\system32\\cmd.exe") == "cmd.exe"
    assert sanitize_filename("normal_doc.pdf") == "normal_doc.pdf"
    assert sanitize_filename("doc with spaces and !@#.pdf") == "doc with spaces and ___.pdf"


def test_empty_file_rejected():
    is_valid, mime, err = validate_file_content("test.pdf", b"")
    assert is_valid is False
    assert "empty" in err.lower()


def test_disallowed_extension_rejected():
    is_valid, mime, err = validate_file_content("malicious.exe", b"\x4d\x5a\x90\x00")
    assert is_valid is False
    assert "not permitted" in err.lower()


def test_valid_pdf_magic_bytes():
    pdf_bytes = b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF"
    is_valid, mime, err = validate_file_content("document.pdf", pdf_bytes)
    assert is_valid is True
    assert mime == "application/pdf"
    assert err == ""


def test_spoofed_pdf_rejected():
    # Plain text renamed to .pdf
    fake_pdf = b"This is just plain text, not a PDF."
    is_valid, mime, err = validate_file_content("fake.pdf", fake_pdf)
    assert is_valid is False
    assert "magic bytes" in err.lower()


def test_valid_png_magic_bytes():
    png_bytes = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"
    is_valid, mime, err = validate_file_content("photo.png", png_bytes)
    assert is_valid is True
    assert mime == "image/png"


def test_valid_text_and_json():
    # Plain text
    txt_bytes = "Hello TrustVault secure world!".encode("utf-8")
    is_valid, mime, err = validate_file_content("notes.txt", txt_bytes)
    assert is_valid is True
    assert mime == "text/plain"

    # JSON
    json_bytes = '{"status": "ok", "confidential": true}'.encode("utf-8")
    is_valid, mime, err = validate_file_content("data.json", json_bytes)
    assert is_valid is True
    assert mime == "application/json"

    # Invalid JSON
    is_valid, mime, err = validate_file_content("invalid.json", b"{broken json")
    assert is_valid is False
