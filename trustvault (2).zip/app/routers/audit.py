"""
TrustVault Audit Router
Provides secure endpoints for viewing audit trails and verifying SHA-256 hash-chain integrity.
"""
import json
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from app.core.csrf import check_csrf
from app.core.permissions import require_document_access
from app.core.sessions import get_current_user
from app.database.session import get_db
from app.models.audit_event import AuditEvent
from app.models.user import User
from app.schemas.audit import AuditListResponse, AuditEventResponse, AuditVerificationResult
from app.services.audit_service import AuditService

router = APIRouter(prefix="/api/audit", tags=["Audit"])


@router.get("", response_model=AuditListResponse)
def get_audit_trail(
    action: Optional[str] = None,
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Query audit trail. Administrators have full system visibility.
    Non-admin users can view events they initiated or events on documents they own.
    """
    query = db.query(AuditEvent)

    if current_user.role != "admin":
        # Scoped to events where user is actor
        query = query.filter(AuditEvent.actor_id == current_user.id)

    if action:
        query = query.filter(AuditEvent.action == action)
    if resource_type:
        query = query.filter(AuditEvent.resource_type == resource_type)
    if resource_id:
        query = query.filter(AuditEvent.resource_id == resource_id)

    total = query.count()
    events = query.order_by(AuditEvent.sequence_number.desc()).offset(offset).limit(limit).all()

    items = []
    for ev in events:
        try:
            meta = json.loads(ev.metadata_json)
        except Exception:
            meta = {}

        item = AuditEventResponse(
            id=ev.id,
            sequence_number=ev.sequence_number,
            actor_id=ev.actor_id,
            actor_email=ev.actor_email,
            action=ev.action,
            resource_type=ev.resource_type,
            resource_id=ev.resource_id,
            outcome=ev.outcome,
            ip_address=ev.ip_address,
            user_agent=ev.user_agent,
            metadata=meta,
            timestamp_utc=ev.timestamp_utc,
            previous_hash=ev.previous_hash,
            current_hash=ev.current_hash,
        )
        items.append(item)

    return AuditListResponse(total=total, items=items)


@router.get("/documents/{document_id}", response_model=AuditListResponse)
def get_document_audit_history(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get access and modification history for a specific document.
    Requires at least READ permission on the document.
    """
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    doc, _ = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="READ",
        ip_address=ip,
        user_agent=ua
    )

    events = (
        db.query(AuditEvent)
        .filter(AuditEvent.resource_id == doc.id)
        .order_by(AuditEvent.sequence_number.desc())
        .limit(100)
        .all()
    )

    items = []
    for ev in events:
        try:
            meta = json.loads(ev.metadata_json)
        except Exception:
            meta = {}
        item = AuditEventResponse(
            id=ev.id,
            sequence_number=ev.sequence_number,
            actor_id=ev.actor_id,
            actor_email=ev.actor_email,
            action=ev.action,
            resource_type=ev.resource_type,
            resource_id=ev.resource_id,
            outcome=ev.outcome,
            ip_address=ev.ip_address,
            user_agent=ev.user_agent,
            metadata=meta,
            timestamp_utc=ev.timestamp_utc,
            previous_hash=ev.previous_hash,
            current_hash=ev.current_hash,
        )
        items.append(item)

    return AuditListResponse(total=len(items), items=items)


@router.post("/verify", response_model=AuditVerificationResult)
def verify_audit_chain(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Independently verifies the complete cryptographic SHA-256 hash chain.
    Recalculates every event's canonical digest from genesis to latest record,
    checking for any tampered records, broken links, or deleted events.
    """
    check_csrf(request)
    result = AuditService.verify_chain(db)

    # Log this verification action itself
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    AuditService.log_event(
        db=db,
        action="AUDIT_VERIFICATION_PERFORMED",
        resource_type="SYSTEM",
        resource_id=None,
        outcome="SUCCESS" if result["is_valid"] else "FAILURE",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "is_valid": result["is_valid"],
            "total_events_verified": result["total_events_verified"],
            "broken_at_sequence": result["broken_at_sequence"],
        }
    )

    return AuditVerificationResult(**result)
