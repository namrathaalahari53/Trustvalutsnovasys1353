"""
Integration tests for authentication API endpoints
"""
from app.core.config import SESSION_COOKIE_NAME, CSRF_COOKIE_NAME


def test_user_registration_and_login_flow(client):
    # Register new user
    reg_payload = {
        "email": "tester1@trustvault.local",
        "username": "tester1",
        "password": "StrongPassword#2026!",
    }
    r = client.post("/api/auth/register", json=reg_payload)
    assert r.status_code == 201
    data = r.json()
    assert data["user"]["email"] == "tester1@trustvault.local"
    assert "csrf_token" in data
    assert SESSION_COOKIE_NAME in client.cookies

    # Duplicate registration rejected
    r_dup = client.post("/api/auth/register", json=reg_payload)
    assert r_dup.status_code == 400
    assert "already registered" in r_dup.text

    # Weak password rejected
    r_weak = client.post("/api/auth/register", json={
        "email": "weak@trustvault.local",
        "username": "weakuser",
        "password": "123",
    })
    assert r_weak.status_code in (400, 422)

    # Logout
    csrf_token = data.get("csrf_token")
    r_logout = client.post("/api/auth/logout", headers={"X-CSRF-Token": csrf_token} if csrf_token else {})
    assert r_logout.status_code == 200

    # /api/auth/me should fail when logged out
    r_me = client.get("/api/auth/me")
    assert r_me.status_code == 401

    # Login with valid credentials
    r_login = client.post("/api/auth/login", json={
        "email": "tester1@trustvault.local",
        "password": "StrongPassword#2026!",
    })
    assert r_login.status_code == 200
    assert r_login.json()["user"]["username"] == "tester1"
    assert SESSION_COOKIE_NAME in client.cookies

    # /api/auth/me should succeed
    r_me_ok = client.get("/api/auth/me")
    assert r_me_ok.status_code == 200
    assert r_me_ok.json()["user"]["email"] == "tester1@trustvault.local"


def test_invalid_login_credentials(client):
    r = client.post("/api/auth/login", json={
        "email": "nonexistent@trustvault.local",
        "password": "WrongPassword123!",
    })
    assert r.status_code == 401
    assert "Invalid email or password" in r.text


def test_password_reset_flow(client):
    # Register user
    client.post("/api/auth/register", json={
        "email": "resetme@trustvault.local",
        "username": "resetme",
        "password": "InitialPassword123!",
    })

    # Request reset token
    r_forgot = client.post("/api/auth/forgot-password", json={"email": "resetme@trustvault.local"})
    assert r_forgot.status_code == 200
    token = r_forgot.json().get("reset_token")
    assert token is not None

    # Reset password with token
    r_reset = client.post("/api/auth/reset-password", json={
        "token": token,
        "new_password": "NewStrongPassword#2026!",
    })
    assert r_reset.status_code == 200

    # Reusing the same reset token must fail (single-use constraint)
    r_reuse = client.post("/api/auth/reset-password", json={
        "token": token,
        "new_password": "AnotherPassword#2026!",
    })
    assert r_reuse.status_code == 400
    assert "already been used" in r_reuse.text or "invalid" in r_reuse.text

    # Login with old password must fail
    r_old = client.post("/api/auth/login", json={
        "email": "resetme@trustvault.local",
        "password": "InitialPassword123!",
    })
    assert r_old.status_code == 401

    # Login with new password must succeed
    r_new = client.post("/api/auth/login", json={
        "email": "resetme@trustvault.local",
        "password": "NewStrongPassword#2026!",
    })
    assert r_new.status_code == 200


def test_bearer_and_custom_header_session_persistence(client):
    # Register user
    r_reg = client.post("/api/auth/register", json={
        "email": "headertest@trustvault.local",
        "username": "headertest",
        "password": "HeaderPassword#2026!",
    })
    assert r_reg.status_code == 201
    token = r_reg.json()["session_token"]
    assert token is not None

    # Clear all cookies to simulate cross-origin iframe cookie blocking
    client.cookies.clear()

    # 1. Access /api/auth/me using Authorization: Bearer <token>
    r_bearer = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert r_bearer.status_code == 200
    assert r_bearer.json()["user"]["username"] == "headertest"

    # 2. Access /api/auth/me using X-Session-Token
    r_custom = client.get("/api/auth/me", headers={"X-Session-Token": token})
    assert r_custom.status_code == 200
    assert r_custom.json()["user"]["email"] == "headertest@trustvault.local"
