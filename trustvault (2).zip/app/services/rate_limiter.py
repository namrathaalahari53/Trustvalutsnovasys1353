"""
TrustVault In-Memory Sliding Window Rate Limiter
Defends against brute-force attacks and credential stuffing on authentication endpoints.
"""
import time
import threading
from collections import defaultdict
from typing import Tuple, Dict, List

_rate_limit_lock = threading.Lock()
_request_records: Dict[str, List[float]] = defaultdict(list)


class RateLimiter:
    @staticmethod
    def is_rate_limited(key: str, max_attempts: int, window_seconds: int, record: bool = True) -> Tuple[bool, int]:
        """
        Check if key has reached or exceeded max_attempts in window_seconds.
        If record=True, adds current timestamp when not limited.
        Returns: (is_limited, retry_after_seconds)
        """
        now = time.time()
        cutoff = now - window_seconds

        with _rate_limit_lock:
            # Purge timestamps older than window
            timestamps = [ts for ts in _request_records[key] if ts > cutoff]
            _request_records[key] = timestamps

            if len(timestamps) >= max_attempts:
                oldest = timestamps[0]
                retry_after = int(oldest + window_seconds - now) + 1
                return True, max(1, retry_after)

            if record:
                timestamps.append(now)
                _request_records[key] = timestamps

            return False, 0

    @staticmethod
    def record_failure(key: str) -> None:
        """Explicitly record a failed attempt."""
        now = time.time()
        with _rate_limit_lock:
            _request_records[key].append(now)

    @staticmethod
    def reset(key: str) -> None:
        """Reset rate limit history for a key on successful action."""
        with _rate_limit_lock:
            if key in _request_records:
                del _request_records[key]

    @staticmethod
    def clear_all() -> None:
        """Utility for test suites."""
        with _rate_limit_lock:
            _request_records.clear()
