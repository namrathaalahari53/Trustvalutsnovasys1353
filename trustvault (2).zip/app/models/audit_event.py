"""
Audit Event database model for SHA-256 tamper-evident hash chaining.
"""
import uuid
from sqlalchemy import Column, String, Integer, Text, Index
from app.database.session import Base


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    sequence_number = Column(Integer, unique=True, nullable=False, index=True)
    actor_id = Column(String(36), nullable=True, index=True)
    actor_email = Column(String(255), nullable=True)
    action = Column(String(64), nullable=False, index=True)
    resource_type = Column(String(32), nullable=False, index=True)
    resource_id = Column(String(36), nullable=True, index=True)
    outcome = Column(String(16), nullable=False)  # "SUCCESS", "FAILURE", "DENIED"
    ip_address = Column(String(64), nullable=True)
    user_agent = Column(String(255), nullable=True)
    metadata_json = Column(Text, nullable=False, default="{}")
    timestamp_utc = Column(String(32), nullable=False, index=True)
    previous_hash = Column(String(64), nullable=False)
    current_hash = Column(String(64), unique=True, nullable=False, index=True)

    __table_args__ = (
        Index("idx_audit_actor_action", "actor_id", "action"),
        Index("idx_audit_resource", "resource_type", "resource_id"),
        Index("idx_audit_seq_hash", "sequence_number", "current_hash"),
    )
