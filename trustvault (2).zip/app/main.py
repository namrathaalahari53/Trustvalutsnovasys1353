"""
TrustVault Main Application Entrypoint
FastAPI application configuration, router mounting, database initialization,
and static asset serving.
"""
import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request, status, HTTPException
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.core.config import BASE_DIR, STORAGE_DIR, ENVIRONMENT
from app.core.security import hash_password
from app.database.session import engine, Base, SessionLocal
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.models.user import User
from app.models.document import Document
from app.models.permission import DocumentPermission
from app.models.session import UserSession
from app.models.audit_event import AuditEvent
from app.models.reset_token import PasswordResetToken
from app.routers import auth, documents, permissions, audit, admin
from app.services.audit_service import AuditService


def init_db():
    """Create all tables and seed initial administrator if not present."""
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        # Check if any admin user exists
        admin_user = db.query(User).filter(User.role == "admin").first()
        if not admin_user:
            admin_user = User(
                email="admin@trustvault.local",
                username="admin",
                hashed_password=hash_password("TrustVault2026!Admin#"),
                role="admin",
                is_active=True,
            )
            db.add(admin_user)
            db.commit()
            db.refresh(admin_user)

            AuditService.log_event(
                db=db,
                action="SYSTEM_INIT_ADMIN",
                resource_type="USER",
                resource_id=admin_user.id,
                outcome="SUCCESS",
                actor_id=admin_user.id,
                actor_email=admin_user.email,
                metadata={"info": "Initial bootstrap admin account created."}
            )

        # Create demo standard user for convenient out-of-the-box sharing tests
        demo_user = db.query(User).filter(User.email == "alice@trustvault.local").first()
        if not demo_user:
            demo_user = User(
                email="alice@trustvault.local",
                username="alice",
                hashed_password=hash_password("TrustVault2026!Alice#"),
                role="user",
                is_active=True,
            )
            db.add(demo_user)
            db.commit()
            db.refresh(demo_user)

            AuditService.log_event(
                db=db,
                action="SYSTEM_INIT_USER",
                resource_type="USER",
                resource_id=demo_user.id,
                outcome="SUCCESS",
                actor_id=demo_user.id,
                actor_email=demo_user.email,
                metadata={"info": "Demo user Alice created."}
            )

            bob_user = User(
                email="bob@trustvault.local",
                username="bob",
                hashed_password=hash_password("TrustVault2026!Bob#"),
                role="user",
                is_active=True,
            )
            db.add(bob_user)
            db.commit()
            db.refresh(bob_user)

            AuditService.log_event(
                db=db,
                action="SYSTEM_INIT_USER",
                resource_type="USER",
                resource_id=bob_user.id,
                outcome="SUCCESS",
                actor_id=bob_user.id,
                actor_email=bob_user.email,
                metadata={"info": "Demo user Bob created."}
            )
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: ensure DB and directories ready
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    init_db()
    yield
    # Shutdown cleanups if needed


app = FastAPI(
    title="TrustVault — Secure Document Sharing with a Real Audit Trail",
    description="Enterprise-grade document security with Argon2id auth, default-deny authorization, and SHA-256 hash-chained audit logging.",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

# Apply Security Headers Middleware
app.add_middleware(SecurityHeadersMiddleware)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(auth.router)
app.include_router(documents.router)
app.include_router(permissions.router)
app.include_router(audit.router)
app.include_router(admin.router)


@app.get("/api/health")
def health_check():
    """Health check endpoint for production orchestration & monitoring."""
    return {
        "status": "healthy",
        "service": "TrustVault",
        "version": "1.0.0",
        "environment": ENVIRONMENT
    }


# Static and UI template paths
STATIC_DIR = BASE_DIR / "app" / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "css").mkdir(parents=True, exist_ok=True)
(STATIC_DIR / "js").mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

TEMPLATE_FILE = BASE_DIR / "app" / "templates" / "index.html"


@app.get("/", response_class=HTMLResponse)
def serve_index():
    """Serve the single-page application entrypoint."""
    if TEMPLATE_FILE.exists():
        with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>TrustVault Backend is running. Frontend template loading...</h1>")


# Fallback for client-side routing
@app.get("/{full_path:path}", response_class=HTMLResponse)
def serve_spa_routes(full_path: str):
    if full_path.startswith("api/") or full_path.startswith("static/"):
        raise HTTPException(status_code=404, detail="Not Found")
    if TEMPLATE_FILE.exists():
        with open(TEMPLATE_FILE, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    raise HTTPException(status_code=404, detail="Not Found")
