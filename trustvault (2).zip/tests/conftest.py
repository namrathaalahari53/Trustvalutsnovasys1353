"""
Pytest configuration and fixtures for TrustVault
"""
import os
import tempfile
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Set test environment
os.environ["ENVIRONMENT"] = "testing"
os.environ["SECRET_KEY"] = "test_secret_key_999999999999999999999999999"

from app.database.session import Base, get_db
from app.main import app
from app.services.rate_limiter import RateLimiter

TEST_DB_FILE = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
TEST_DATABASE_URL = f"sqlite:///{TEST_DB_FILE.name}"

engine_test = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine_test)


@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.create_all(bind=engine_test)
    yield
    Base.metadata.drop_all(bind=engine_test)
    if os.path.exists(TEST_DB_FILE.name):
        try:
            os.unlink(TEST_DB_FILE.name)
        except OSError:
            pass


@pytest.fixture(autouse=True)
def reset_rate_limiters():
    """Reset rate limiter state before each test."""
    RateLimiter.clear_all()


@pytest.fixture
def db():
    """Yield a database session per test with automatic rollback/cleanup."""
    connection = engine_test.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)

    yield session

    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture
def client(db):
    """Test client with overridden database dependency."""
    def override_get_db():
        try:
            yield db
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
