"""
Security Tests: Brute-force protection & Rate Limiting
"""


def test_login_brute_force_rate_limiting(client):
    # Register victim user
    client.post("/api/auth/register", json={
        "email": "victim_brute@trustvault.local",
        "username": "victim_brute",
        "password": "CorrectPassword123!",
    })
    client.cookies.clear()

    # Attempt 5 consecutive failed logins with wrong password
    for i in range(5):
        r_fail = client.post("/api/auth/login", json={
            "email": "victim_brute@trustvault.local",
            "password": f"WrongAttempt{i}!",
        })
        assert r_fail.status_code == 401

    # 6th attempt must trigger 429 Too Many Requests
    r_limited = client.post("/api/auth/login", json={
        "email": "victim_brute@trustvault.local",
        "password": "EvenIfCorrectNow!",
    })
    assert r_limited.status_code == 429
    assert "Too many failed login attempts" in r_limited.text
