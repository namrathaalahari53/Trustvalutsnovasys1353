"""
Administrator schemas
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class AdminUserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: str = Field(..., pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
    username: str
    role: str
    is_active: bool
    created_at: datetime
    documents_count: int = 0
    active_sessions_count: int = 0


class AdminUserStatusUpdateRequest(BaseModel):
    is_active: bool


class SystemStatsResponse(BaseModel):
    total_users: int
    active_users: int
    disabled_users: int
    total_documents: int
    total_audit_events: int
    audit_chain_valid: bool
    recent_denied_events_count: int
