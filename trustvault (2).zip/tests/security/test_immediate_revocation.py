"""
Security Tests: Mandatory Immediate Permission Revocation Workflow
Tests step-by-step revocation enforcement:
1. User A uploads a private document.
2. User A shares it with User B.
3. User B opens it successfully.
4. User A revokes User B's permission.
5. User B retries the same document request -> access denied (403/404).
6. User B retries download URL -> access denied (403/404).
7. Denied attempts are recorded in the audit trail.
"""
import io


def test_mandatory_immediate_revocation_workflow(client):
    # 1. User A (Alice) registers
    client.post("/api/auth/register", json={
        "email": "alice_rev@trustvault.local",
        "username": "alice_rev",
        "password": "Password#2026AliceRev!",
    })

    # User B (Bob) registers
    client.cookies.clear()
    client.post("/api/auth/register", json={
        "email": "bob_rev@trustvault.local",
        "username": "bob_rev",
        "password": "Password#2026BobRev!",
    })

    # User A logs in
    client.cookies.clear()
    r_a = client.post("/api/auth/login", json={
        "email": "alice_rev@trustvault.local",
        "password": "Password#2026AliceRev!",
    })
    csrf_a = r_a.json()["csrf_token"]

    # Step 1: User A uploads private document
    pdf_content = b"%PDF-1.4\n1 0 obj\n<< /Topic (Revocation Test) >>\nendobj\ntrailer\n<<>>\n%%EOF"
    r_up = client.post(
        "/api/documents",
        data={"title": "M&A Agreement"},
        files={"file": ("mna.pdf", io.BytesIO(pdf_content), "application/pdf")},
        headers={"X-CSRF-Token": csrf_a}
    )
    assert r_up.status_code == 201
    doc_id = r_up.json()["id"]

    # Step 2: User A shares document with User B (READ permission)
    r_grant = client.post(
        f"/api/documents/{doc_id}/permissions",
        json={"user_email": "bob_rev@trustvault.local", "permission": "READ"},
        headers={"X-CSRF-Token": csrf_a}
    )
    assert r_grant.status_code == 201
    perm_id = r_grant.json()["id"]

    # Step 3: User B logs in and opens document successfully
    client.cookies.clear()
    client.post("/api/auth/login", json={
        "email": "bob_rev@trustvault.local",
        "password": "Password#2026BobRev!",
    })
    
    r_b_read = client.get(f"/api/documents/{doc_id}")
    assert r_b_read.status_code == 200
    assert r_b_read.json()["title"] == "M&A Agreement"

    r_b_download = client.get(f"/api/documents/{doc_id}/download")
    assert r_b_download.status_code == 200
    assert r_b_download.content == pdf_content

    # Step 4: User A logs back in and REVOKES User B's permission
    client.cookies.clear()
    r_a_login = client.post("/api/auth/login", json={
        "email": "alice_rev@trustvault.local",
        "password": "Password#2026AliceRev!",
    })
    csrf_a = r_a_login.json()["csrf_token"]

    r_revoke = client.delete(f"/api/permissions/{perm_id}", headers={"X-CSRF-Token": csrf_a})
    assert r_revoke.status_code == 200

    # Step 5: User B switches back and immediately retries the SAME document request
    client.cookies.clear()
    client.post("/api/auth/login", json={
        "email": "bob_rev@trustvault.local",
        "password": "Password#2026BobRev!",
    })

    # Access must be denied immediately (403 or 404)
    r_b_retry = client.get(f"/api/documents/{doc_id}")
    assert r_b_retry.status_code in (403, 404)

    # Step 6: User B retries the old download URL
    r_b_retry_down = client.get(f"/api/documents/{doc_id}/download")
    assert r_b_retry_down.status_code in (403, 404)

    # Step 7: Inspect audit trail to verify that denied attempt was audited
    client.cookies.clear()
    client.post("/api/auth/login", json={
        "email": "alice_rev@trustvault.local",
        "password": "Password#2026AliceRev!",
    })

    r_audit = client.get(f"/api/audit/documents/{doc_id}")
    assert r_audit.status_code == 200
    events = r_audit.json()["items"]
    
    denied_events = [e for e in events if e["action"] == "ACCESS_DENIED"]
    assert len(denied_events) > 0
    assert denied_events[0]["outcome"] == "DENIED"
