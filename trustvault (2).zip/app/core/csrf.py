"""
TrustVault CSRF Protection
Double-submit / header-based anti-CSRF token verification for state-changing requests.
"""
import hmac
import hashlib
from typing import Optional
from fastapi import Request, HTTPException, status
from app.core.config import SECRET_KEY, CSRF_COOKIE_NAME, CSRF_HEADER_NAME
from app.core.security import generate_secure_token


def generate_csrf_token() -> str:
    """Generate a high-entropy random CSRF token."""
    return generate_secure_token(32)


def sign_csrf_token(token: str) -> str:
    """Sign CSRF token with HMAC-SHA256."""
    signature = hmac.new(
        SECRET_KEY.encode("utf-8"),
        token.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return f"{token}.{signature}"


def verify_csrf_token(raw_signed_token: str) -> bool:
    """Verify signed CSRF token validity."""
    if not raw_signed_token or "." not in raw_signed_token:
        return False
    parts = raw_signed_token.split(".", 1)
    if len(parts) != 2:
        return False
    token, expected_signature = parts
    computed_signature = hmac.new(
        SECRET_KEY.encode("utf-8"),
        token.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected_signature, computed_signature)


def check_csrf(request: Request) -> None:
    """
    Validate CSRF for state-changing HTTP methods.
    Accepts verified HMAC-signed header tokens or matching header/cookie double-submit pairs.
    Exempts idempotent GET, HEAD, OPTIONS.
    """
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return

    header_token = request.headers.get(CSRF_HEADER_NAME)
    cookie_token = request.cookies.get(CSRF_COOKIE_NAME)

    # 1. Accept valid signed header token
    if header_token and verify_csrf_token(header_token):
        return

    # 2. Accept matching double-submit cookie pair
    if header_token and cookie_token and hmac.compare_digest(header_token, cookie_token):
        return

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="CSRF verification failed: Missing or invalid CSRF token."
    )
