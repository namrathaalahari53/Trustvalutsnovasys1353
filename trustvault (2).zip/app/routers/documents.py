"""
TrustVault Documents Router
Handles secure document uploading with file signature validation, metadata management,
search, filtering, download streaming, and deletion.
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, Form, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_
from app.core.csrf import check_csrf
from app.core.permissions import require_document_access, AuthorizationEngine
from app.core.sessions import get_current_user
from app.database.session import get_db
from app.models.document import Document
from app.models.permission import DocumentPermission
from app.models.user import User
from app.schemas.document import DocumentResponse, DocumentListResponse, DocumentUpdateRequest
from app.services.audit_service import AuditService
from app.services.storage_service import StorageService, validate_file_content, sanitize_filename

router = APIRouter(prefix="/api/documents", tags=["Documents"])


@router.post("", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    request: Request,
    file: UploadFile = File(...),
    title: str = Form(...),
    description: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Read uploaded bytes into memory (subject to size limit)
    content = await file.read()
    raw_filename = file.filename or "document.bin"
    clean_name = sanitize_filename(raw_filename)

    # Strict file content and signature validation
    is_valid, mime_type, err_msg = validate_file_content(clean_name, content)
    if not is_valid:
        AuditService.log_event(
            db=db,
            action="DOCUMENT_UPLOAD_FAILED",
            resource_type="DOCUMENT",
            outcome="FAILURE",
            actor_id=current_user.id,
            actor_email=current_user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={"filename": clean_name, "reason": err_msg}
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err_msg)

    # Save to private filesystem storage with randomized UUID
    storage_fn, file_hash, file_size = StorageService.save_file(content)

    doc_title = title.strip() or clean_name
    new_doc = Document(
        owner_id=current_user.id,
        title=doc_title,
        description=description.strip() if description else None,
        original_filename=clean_name,
        storage_filename=storage_fn,
        file_size=file_size,
        mime_type=mime_type,
        file_hash_sha256=file_hash,
        is_deleted=False,
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)

    AuditService.log_event(
        db=db,
        action="DOCUMENT_UPLOAD",
        resource_type="DOCUMENT",
        resource_id=new_doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "title": new_doc.title,
            "filename": clean_name,
            "file_size": file_size,
            "sha256": file_hash,
            "mime_type": mime_type,
        }
    )

    resp = DocumentResponse.model_validate(new_doc)
    resp.owner_username = current_user.username
    resp.owner_email = current_user.email
    resp.is_owner = True
    resp.current_user_permission = "OWNER"
    return resp


@router.get("", response_model=DocumentListResponse)
def list_documents(
    search: Optional[str] = None,
    filter_type: Optional[str] = None,
    scope: str = "all",  # "all", "owned", "shared"
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List documents the user is authorized to access:
    - Owned by the user
    - Explicitly shared with the user via DocumentPermission
    Admin users can review all system documents if scope='admin'.
    """
    if current_user.role == "admin" and scope == "admin":
        base_query = db.query(Document).filter(Document.is_deleted == False)
    elif scope == "owned":
        base_query = db.query(Document).filter(
            Document.owner_id == current_user.id,
            Document.is_deleted == False
        )
    elif scope == "shared":
        shared_doc_ids = (
            db.query(DocumentPermission.document_id)
            .filter(DocumentPermission.user_id == current_user.id)
            .subquery()
        )
        base_query = db.query(Document).filter(
            Document.id.in_(shared_doc_ids),
            Document.is_deleted == False
        )
    else:  # "all"
        shared_doc_ids = (
            db.query(DocumentPermission.document_id)
            .filter(DocumentPermission.user_id == current_user.id)
            .subquery()
        )
        base_query = db.query(Document).filter(
            Document.is_deleted == False,
            or_(
                Document.owner_id == current_user.id,
                Document.id.in_(shared_doc_ids)
            )
        )

    if search:
        search_pattern = f"%{search.strip()}%"
        base_query = base_query.filter(
            or_(
                Document.title.ilike(search_pattern),
                Document.original_filename.ilike(search_pattern),
                Document.description.ilike(search_pattern)
            )
        )

    if filter_type:
        ft = filter_type.strip().lower()
        base_query = base_query.filter(Document.original_filename.ilike(f"%.{ft}"))

    total = base_query.count()
    docs = base_query.order_by(Document.created_at.desc()).all()

    # Annotate responses with owner and current user permission
    results = []
    for doc in docs:
        item = DocumentResponse.model_validate(doc)
        item.owner_username = doc.owner.username if doc.owner else "Unknown"
        item.owner_email = doc.owner.email if doc.owner else ""
        if doc.owner_id == current_user.id:
            item.is_owner = True
            item.current_user_permission = "OWNER"
        else:
            item.is_owner = False
            perm = (
                db.query(DocumentPermission)
                .filter(
                    DocumentPermission.document_id == doc.id,
                    DocumentPermission.user_id == current_user.id
                )
                .first()
            )
            item.current_user_permission = perm.permission if perm else ("ADMIN_READ" if current_user.role == "admin" else "NONE")
        results.append(item)

    return DocumentListResponse(total=total, items=results)


@router.get("/{document_id}", response_model=DocumentResponse)
def get_document(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    doc, eff_perm = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="READ",
        ip_address=ip,
        user_agent=ua
    )

    AuditService.log_event(
        db=db,
        action="DOCUMENT_READ",
        resource_type="DOCUMENT",
        resource_id=doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={"title": doc.title, "permission": eff_perm}
    )

    resp = DocumentResponse.model_validate(doc)
    resp.owner_username = doc.owner.username if doc.owner else "Unknown"
    resp.owner_email = doc.owner.email if doc.owner else ""
    resp.is_owner = (doc.owner_id == current_user.id)
    resp.current_user_permission = eff_perm
    return resp


@router.patch("/{document_id}", response_model=DocumentResponse)
def update_document(
    document_id: str,
    update_data: DocumentUpdateRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Authorize EDIT permission (Owner or shared user with EDIT)
    doc, eff_perm = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="EDIT",
        ip_address=ip,
        user_agent=ua
    )

    changed_fields = {}
    if update_data.title is not None and update_data.title.strip():
        changed_fields["old_title"] = doc.title
        doc.title = update_data.title.strip()
        changed_fields["new_title"] = doc.title

    if update_data.description is not None:
        doc.description = update_data.description.strip() or None
        changed_fields["description_updated"] = True

    db.commit()
    db.refresh(doc)

    AuditService.log_event(
        db=db,
        action="DOCUMENT_UPDATE",
        resource_type="DOCUMENT",
        resource_id=doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata=changed_fields
    )

    resp = DocumentResponse.model_validate(doc)
    resp.owner_username = doc.owner.username if doc.owner else "Unknown"
    resp.owner_email = doc.owner.email if doc.owner else ""
    resp.is_owner = (doc.owner_id == current_user.id)
    resp.current_user_permission = eff_perm
    return resp


@router.delete("/{document_id}")
def delete_document(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Strict: DELETE is OWNER-ONLY. Viewers with EDIT can NEVER delete a document.
    doc, _ = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="DELETE",
        ip_address=ip,
        user_agent=ua
    )

    # Soft-delete record and safely delete physical file
    doc.is_deleted = True
    StorageService.delete_file(doc.storage_filename)
    db.commit()

    AuditService.log_event(
        db=db,
        action="DOCUMENT_DELETE",
        resource_type="DOCUMENT",
        resource_id=doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={"title": doc.title, "filename": doc.original_filename}
    )

    return {"message": "Document deleted successfully."}


@router.get("/{document_id}/download")
def download_document(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Safely streams file after checking real-time authoritative permissions.
    If permissions were revoked moments before, access is immediately blocked.
    """
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    doc, eff_perm = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="READ",
        ip_address=ip,
        user_agent=ua
    )

    file_path = StorageService.get_file_path(doc.storage_filename)

    AuditService.log_event(
        db=db,
        action="DOCUMENT_DOWNLOAD",
        resource_type="DOCUMENT",
        resource_id=doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "title": doc.title,
            "filename": doc.original_filename,
            "permission": eff_perm,
            "sha256": doc.file_hash_sha256
        }
    )

    return FileResponse(
        path=file_path,
        media_type=doc.mime_type,
        filename=doc.original_filename,
        content_disposition_type="attachment",
    )
