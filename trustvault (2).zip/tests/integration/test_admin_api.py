"""
Integration tests for Administrator API and Account Deactivation
"""


def test_admin_access_control_and_user_deactivation(client):
    # 1. Register first user (automatically becomes admin)
    r_adm = client.post("/api/auth/register", json={
        "email": "sysadmin@trustvault.local",
        "username": "sysadmin",
        "password": "AdminPassword#2026!",
    })
    csrf_admin = r_adm.json()["csrf_token"]

    # 2. Register standard user
    client.cookies.clear()
    client.post("/api/auth/register", json={
        "email": "standarduser@trustvault.local",
        "username": "standarduser",
        "password": "UserPassword#2026!",
    })

    # Standard user attempts to call admin endpoints -> 403 Forbidden
    r_unauth_users = client.get("/api/admin/users")
    assert r_unauth_users.status_code == 403

    r_unauth_stats = client.get("/api/admin/stats")
    assert r_unauth_stats.status_code == 403

    # Switch back to admin
    client.cookies.clear()
    r_adm_login = client.post("/api/auth/login", json={
        "email": "sysadmin@trustvault.local",
        "password": "AdminPassword#2026!",
    })
    csrf_admin = r_adm_login.json()["csrf_token"]

    # Admin lists users
    r_users = client.get("/api/admin/users")
    assert r_users.status_code == 200
    user_list = r_users.json()
    assert len(user_list) >= 2

    # Find standard user ID
    target = next(u for u in user_list if u["email"] == "standarduser@trustvault.local")
    target_id = target["id"]

    # Admin deactivates standard user
    r_deact = client.patch(
        f"/api/admin/users/{target_id}/status",
        json={"is_active": False},
        headers={"X-CSRF-Token": csrf_admin}
    )
    assert r_deact.status_code == 200
    assert r_deact.json()["is_active"] is False

    # Standard user attempts to log in -> blocked with 403 Forbidden
    client.cookies.clear()
    r_login_blocked = client.post("/api/auth/login", json={
        "email": "standarduser@trustvault.local",
        "password": "UserPassword#2026!",
    })
    assert r_login_blocked.status_code == 403
    assert "deactivated" in r_login_blocked.text.lower()
