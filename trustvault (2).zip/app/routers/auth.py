"""
TrustVault Authentication Router
Handles user registration, login, logout, profile querying, and secure password reset.
"""
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.orm import Session
from app.core.config import (
    SESSION_COOKIE_NAME,
    CSRF_COOKIE_NAME,
    SECURE_COOKIES,
    RESET_TOKEN_EXPIRE_SECONDS,
)
from app.core.csrf import generate_csrf_token, sign_csrf_token
from app.core.security import (
    hash_password,
    verify_password,
    validate_password_strength,
    generate_secure_token,
    hash_token,
)
from app.core.sessions import SessionManager, get_current_user
from app.database.session import get_db
from app.models.user import User
from app.models.reset_token import PasswordResetToken
from app.schemas.auth import (
    RegisterRequest,
    LoginRequest,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    UserResponse,
    AuthResponse,
)
from app.services.audit_service import AuditService
from app.services.rate_limiter import RateLimiter

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


def set_auth_cookies(response: Response, request: Request, session_token: str, csrf_token: str):
    """Set resilient session and CSRF cookies supporting iframe environments."""
    forwarded_proto = request.headers.get("x-forwarded-proto", "").lower()
    is_https = (forwarded_proto == "https") or (request.url.scheme == "https") or SECURE_COOKIES

    # For HTTPS inside an iframe, SameSite=None is required so modern browsers don't block cookies
    cookie_samesite = "none" if is_https else "lax"
    cookie_secure = True if is_https else False

    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=session_token,
        httponly=True,
        secure=cookie_secure,
        samesite=cookie_samesite,
        max_age=86400,
        path="/",
    )
    response.set_cookie(
        key=CSRF_COOKIE_NAME,
        value=csrf_token,
        httponly=False,
        secure=cookie_secure,
        samesite=cookie_samesite,
        max_age=86400,
        path="/",
    )


@router.post("/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
def register(
    req: RegisterRequest,
    request: Request,
    response: Response,
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Rate limiting on registration
    is_limited, retry_after = RateLimiter.is_rate_limited(f"reg_{ip}", max_attempts=10, window_seconds=60)
    if is_limited:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many registration attempts. Please retry in {retry_after} seconds."
        )

    # Validate password complexity
    valid, msg = validate_password_strength(req.password)
    if not valid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=msg)

    # Check email / username uniqueness
    existing_email = db.query(User).filter(User.email == req.email.lower()).first()
    if existing_email:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email is already registered.")

    existing_username = db.query(User).filter(User.username == req.username).first()
    if existing_username:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username is already taken.")

    # First user can be made admin if none exists, else standard user
    total_users = db.query(User).count()
    role = "admin" if total_users == 0 else "user"

    new_user = User(
        email=req.email.lower(),
        username=req.username,
        hashed_password=hash_password(req.password),
        role=role,
        is_active=True,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Automatically create session upon registration
    raw_token, session_obj = SessionManager.create_session(
        db=db, user_id=new_user.id, ip_address=ip, user_agent=ua
    )

    csrf_raw = generate_csrf_token()
    signed_csrf = sign_csrf_token(csrf_raw)

    set_auth_cookies(response, request, raw_token, signed_csrf)

    AuditService.log_event(
        db=db,
        action="USER_REGISTRATION",
        resource_type="USER",
        resource_id=new_user.id,
        outcome="SUCCESS",
        actor_id=new_user.id,
        actor_email=new_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={"username": new_user.username, "role": new_user.role}
    )

    return AuthResponse(
        user=UserResponse.model_validate(new_user),
        session_token=raw_token,
        csrf_token=signed_csrf,
        message="Registration successful."
    )


@router.post("/login", response_model=AuthResponse)
def login(
    req: LoginRequest,
    request: Request,
    response: Response,
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")
    identifier = req.email.strip().lower()

    # Rate limiting on login attempts per IP and per account identifier
    rate_key = f"login_{ip}_{identifier}"
    is_limited, retry_after = RateLimiter.is_rate_limited(rate_key, max_attempts=5, window_seconds=60, record=False)
    if is_limited:
        AuditService.log_event(
            db=db,
            action="LOGIN_RATE_LIMITED",
            resource_type="USER",
            resource_id=None,
            outcome="FAILURE",
            actor_id=None,
            actor_email=identifier,
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Rate limit exceeded"}
        )
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many failed login attempts. Please wait {retry_after} seconds before trying again."
        )

    # Look up user by email or username
    user = (
        db.query(User)
        .filter((User.email == identifier) | (User.username == req.email.strip()))
        .first()
    )

    if not user or not verify_password(req.password, user.hashed_password):
        RateLimiter.record_failure(rate_key)
        AuditService.log_event(
            db=db,
            action="LOGIN_FAILURE",
            resource_type="USER",
            resource_id=user.id if user else None,
            outcome="FAILURE",
            actor_id=user.id if user else None,
            actor_email=identifier,
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Invalid credentials"}
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password."
        )

    if not user.is_active:
        AuditService.log_event(
            db=db,
            action="LOGIN_FAILURE",
            resource_type="USER",
            resource_id=user.id,
            outcome="FAILURE",
            actor_id=user.id,
            actor_email=user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Account is disabled"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated. Please contact an administrator."
        )

    # Success: reset rate limit history
    RateLimiter.reset(rate_key)

    raw_token, session_obj = SessionManager.create_session(
        db=db, user_id=user.id, ip_address=ip, user_agent=ua
    )

    csrf_raw = generate_csrf_token()
    signed_csrf = sign_csrf_token(csrf_raw)

    set_auth_cookies(response, request, raw_token, signed_csrf)

    AuditService.log_event(
        db=db,
        action="LOGIN_SUCCESS",
        resource_type="USER",
        resource_id=user.id,
        outcome="SUCCESS",
        actor_id=user.id,
        actor_email=user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={"role": user.role}
    )

    return AuthResponse(
        user=UserResponse.model_validate(user),
        session_token=raw_token,
        csrf_token=signed_csrf,
        message="Login successful."
    )


@router.post("/logout")
def logout(
    request: Request,
    response: Response,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if not token:
        token = request.headers.get("X-Session-Token")
    if not token:
        auth_h = request.headers.get("Authorization")
        if auth_h and auth_h.startswith("Bearer "):
            token = auth_h.split(" ", 1)[1].strip()

    if token:
        SessionManager.invalidate_session(db, token)

    response.delete_cookie(key=SESSION_COOKIE_NAME, path="/")
    response.delete_cookie(key=CSRF_COOKIE_NAME, path="/")

    AuditService.log_event(
        db=db,
        action="LOGOUT",
        resource_type="USER",
        resource_id=current_user.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
    )

    return {"message": "Logged out successfully."}


@router.get("/me")
def get_me(
    request: Request,
    response: Response,
    current_user: User = Depends(get_current_user)
):
    csrf_cookie = request.cookies.get(CSRF_COOKIE_NAME)
    if not csrf_cookie:
        csrf_raw = generate_csrf_token()
        csrf_cookie = sign_csrf_token(csrf_raw)
        forwarded_proto = request.headers.get("x-forwarded-proto", "").lower()
        is_https = (forwarded_proto == "https") or (request.url.scheme == "https") or SECURE_COOKIES
        response.set_cookie(
            key=CSRF_COOKIE_NAME,
            value=csrf_cookie,
            httponly=False,
            secure=True if is_https else False,
            samesite="none" if is_https else "lax",
            max_age=86400,
            path="/",
        )

    return {
        "user": UserResponse.model_validate(current_user),
        "csrf_token": csrf_cookie
    }


@router.post("/forgot-password")
def forgot_password(
    req: ForgotPasswordRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Rate limit password resets
    is_limited, retry = RateLimiter.is_rate_limited(f"reset_{ip}", max_attempts=3, window_seconds=300)
    if is_limited:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Too many reset requests. Please wait {retry} seconds."
        )

    user = db.query(User).filter(User.email == req.email.lower()).first()

    # Generic response to prevent user enumeration
    resp_msg = "If that email is registered, a password reset token has been generated."
    raw_token_for_response = None

    if user and user.is_active:
        raw_token = generate_secure_token(32)
        token_hash = hash_token(raw_token)
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(seconds=RESET_TOKEN_EXPIRE_SECONDS)

        # Invalidate old unused tokens
        db.query(PasswordResetToken).filter(
            PasswordResetToken.user_id == user.id,
            PasswordResetToken.used == False
        ).update({"used": True})

        reset_obj = PasswordResetToken(
            user_id=user.id,
            token_hash=token_hash,
            expires_at=expires_at,
            used=False,
            created_at=now,
        )
        db.add(reset_obj)
        db.commit()

        AuditService.log_event(
            db=db,
            action="PASSWORD_RESET_REQUEST",
            resource_type="USER",
            resource_id=user.id,
            outcome="SUCCESS",
            actor_id=user.id,
            actor_email=user.email,
            ip_address=ip,
            user_agent=ua,
        )

        # In development / testing environment, we provide the reset token in response
        raw_token_for_response = raw_token

    return {
        "message": resp_msg,
        "reset_token": raw_token_for_response  # Provided for seamless UI and testing
    }


@router.post("/reset-password")
def reset_password(
    req: ResetPasswordRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    valid, msg = validate_password_strength(req.new_password)
    if not valid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=msg)

    token_hash = hash_token(req.token)
    now = datetime.now(timezone.utc)

    reset_token = (
        db.query(PasswordResetToken)
        .filter(
            PasswordResetToken.token_hash == token_hash,
            PasswordResetToken.used == False,
            PasswordResetToken.expires_at > now,
        )
        .first()
    )

    if not reset_token:
        AuditService.log_event(
            db=db,
            action="PASSWORD_RESET_FAILURE",
            resource_type="USER",
            resource_id=None,
            outcome="FAILURE",
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Invalid or expired token"}
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password reset token is invalid, expired, or has already been used."
        )

    user = db.query(User).filter(User.id == reset_token.user_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Account is disabled.")

    # Update password and mark token used
    user.hashed_password = hash_password(req.new_password)
    reset_token.used = True

    # Invalidate all existing active sessions immediately
    SessionManager.invalidate_all_user_sessions(db, user.id)
    db.commit()

    AuditService.log_event(
        db=db,
        action="PASSWORD_RESET_SUCCESS",
        resource_type="USER",
        resource_id=user.id,
        outcome="SUCCESS",
        actor_id=user.id,
        actor_email=user.email,
        ip_address=ip,
        user_agent=ua,
    )

    return {"message": "Password has been successfully reset. Please log in with your new password."}
