"""
Audit schemas
"""
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, ConfigDict


class AuditEventResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    sequence_number: int
    actor_id: Optional[str] = None
    actor_email: Optional[str] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    outcome: str
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    metadata: Dict[str, Any] = {}
    timestamp_utc: str
    previous_hash: str
    current_hash: str


class AuditListResponse(BaseModel):
    total: int
    items: List[AuditEventResponse]


class AuditVerificationResult(BaseModel):
    is_valid: bool
    total_events_verified: int
    genesis_hash: Optional[str] = None
    latest_hash: Optional[str] = None
    broken_at_sequence: Optional[int] = None
    error_detail: Optional[str] = None
    verified_at: str
