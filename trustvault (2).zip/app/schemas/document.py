"""
Document schemas
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class DocumentUpdateRequest(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=2000)


class DocumentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    owner_id: str
    owner_username: Optional[str] = None
    owner_email: Optional[str] = None
    title: str
    description: Optional[str] = None
    original_filename: str
    file_size: int
    mime_type: str
    file_hash_sha256: str
    is_owner: bool = False
    current_user_permission: Optional[str] = None  # "OWNER", "READ", "EDIT"
    created_at: datetime
    updated_at: datetime


class DocumentListResponse(BaseModel):
    total: int
    items: List[DocumentResponse]
