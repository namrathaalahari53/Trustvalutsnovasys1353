"""
TrustVault Core Configuration
Handles environment-based application settings, file storage constraints,
and cryptographic parameters.
"""
import os
from pathlib import Path
from typing import Set

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Security & Sessions
SECRET_KEY: str = os.getenv("SECRET_KEY", "trustvault_prod_secret_key_89234892347891234789123")
SESSION_COOKIE_NAME: str = "tv_session"
CSRF_COOKIE_NAME: str = "tv_csrf"
CSRF_HEADER_NAME: str = "X-CSRF-Token"
SESSION_EXPIRE_SECONDS: int = int(os.getenv("SESSION_EXPIRE_SECONDS", "86400"))  # 24 hours
RESET_TOKEN_EXPIRE_SECONDS: int = int(os.getenv("RESET_TOKEN_EXPIRE_SECONDS", "900"))  # 15 mins

# Database
DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR}/trustvault.db")

# Storage
STORAGE_DIR: Path = Path(os.getenv("STORAGE_DIR", str(BASE_DIR / "private_storage")))
MAX_UPLOAD_SIZE_BYTES: int = 25 * 1024 * 1024  # 25 MB limit
ALLOWED_EXTENSIONS: Set[str] = {
    "pdf", "docx", "xlsx", "txt", "md", "png", "jpg", "jpeg", "csv", "json"
}

# Environment
ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
SECURE_COOKIES: bool = os.getenv("SECURE_COOKIES", "false").lower() == "true"

# Ensure storage directory exists
STORAGE_DIR.mkdir(parents=True, exist_ok=True)
