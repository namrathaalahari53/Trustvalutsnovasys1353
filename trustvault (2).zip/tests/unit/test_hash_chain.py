"""
Unit tests for SHA-256 Tamper-Evident Hash Chain
"""
from app.models.audit_event import AuditEvent
from app.services.audit_service import AuditService, GENESIS_PREVIOUS_HASH


def test_audit_hash_chain_creation_and_verification(db):
    # Log 3 events
    e1 = AuditService.log_event(
        db=db,
        action="TEST_ACTION_1",
        resource_type="USER",
        outcome="SUCCESS",
        actor_id="actor-1",
        metadata={"k1": "v1"}
    )
    assert e1.sequence_number == 1
    assert e1.previous_hash == GENESIS_PREVIOUS_HASH
    assert len(e1.current_hash) == 64

    e2 = AuditService.log_event(
        db=db,
        action="TEST_ACTION_2",
        resource_type="DOCUMENT",
        outcome="SUCCESS",
        actor_id="actor-1",
        metadata={"k2": "v2"}
    )
    assert e2.sequence_number == 2
    assert e2.previous_hash == e1.current_hash

    e3 = AuditService.log_event(
        db=db,
        action="TEST_ACTION_3",
        resource_type="DOCUMENT",
        outcome="DENIED",
        actor_id="actor-2",
        metadata={"k3": "v3"}
    )
    assert e3.sequence_number == 3
    assert e3.previous_hash == e2.current_hash

    # Verify chain
    result = AuditService.verify_chain(db)
    assert result["is_valid"] is True
    assert result["total_events_verified"] == 3
    assert result["broken_at_sequence"] is None


def test_audit_hash_chain_detects_tampered_payload(db):
    # Log 2 events
    e1 = AuditService.log_event(db=db, action="ACT1", resource_type="TEST", outcome="SUCCESS")
    e2 = AuditService.log_event(db=db, action="ACT2", resource_type="TEST", outcome="SUCCESS")

    # Verify initially valid
    assert AuditService.verify_chain(db)["is_valid"] is True

    # Tamper with event 1 metadata directly in DB
    e1.metadata_json = '{"tampered":true}'
    db.commit()

    # Verification must fail and pinpoint sequence 1
    result = AuditService.verify_chain(db)
    assert result["is_valid"] is False
    assert result["broken_at_sequence"] == 1
    assert "Tampered" in result["error_detail"]


def test_audit_hash_chain_detects_deleted_event(db):
    # Log 3 events
    e1 = AuditService.log_event(db=db, action="ACT1", resource_type="TEST", outcome="SUCCESS")
    e2 = AuditService.log_event(db=db, action="ACT2", resource_type="TEST", outcome="SUCCESS")
    e3 = AuditService.log_event(db=db, action="ACT3", resource_type="TEST", outcome="SUCCESS")

    assert AuditService.verify_chain(db)["is_valid"] is True

    # Maliciously delete intermediate event 2
    db.delete(e2)
    db.commit()

    # Verification must fail and detect missing sequence or broken link
    result = AuditService.verify_chain(db)
    assert result["is_valid"] is False
    assert result["broken_at_sequence"] == 3
    assert "gap" in result["error_detail"].lower() or "broken" in result["error_detail"].lower()
