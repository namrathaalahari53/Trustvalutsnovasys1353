"""
TrustVault Centralized Authorization Engine
Enforces Default-Deny, server-side resource-level authorization, and immediate revocation.
Every permission check queries the authoritative database state in real-time.
"""
from typing import Optional, Tuple
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from app.models.user import User
from app.models.document import Document
from app.models.permission import DocumentPermission
from app.services.audit_service import AuditService


class AuthorizationEngine:
    @staticmethod
    def check_document_access(
        db: Session,
        user: User,
        document_id: str,
        required_action: str,  # "READ", "EDIT", "DELETE", "SHARE", "MANAGE_PERMISSIONS"
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> Tuple[bool, Optional[Document], Optional[str]]:
        """
        Evaluate authorization for a user against a document.
        Returns: (is_authorized, document_obj, effective_permission)
        
        Strict rules:
        1. Default is DENY.
        2. Deactivated users are immediately DENIED.
        3. Deleted documents return 404 to avoid leaking existence, or DENY.
        4. Owner has full permissions (READ, EDIT, DELETE, SHARE).
        5. For shared documents:
           - "READ" requires READ or EDIT permission in DocumentPermission table.
           - "EDIT" requires EDIT permission in DocumentPermission table.
           - "DELETE", "SHARE", "MANAGE_PERMISSIONS" are STRICTLY OWNER-ONLY.
        6. Admins can audit/review documents but cannot delete non-owned without explicit procedure.
        7. On denial, records an ACCESS_DENIED audit event immediately.
        """
        # Rule 1 & 2: Active account check
        if not user or not user.is_active:
            AuditService.log_event(
                db=db,
                action="ACCESS_DENIED",
                resource_type="DOCUMENT",
                resource_id=document_id,
                outcome="DENIED",
                actor_id=user.id if user else None,
                actor_email=user.email if user else None,
                ip_address=ip_address,
                user_agent=user_agent,
                metadata={"reason": "User account inactive or missing", "required_action": required_action}
            )
            return False, None, None

        # Fetch document from authoritative DB
        document = db.query(Document).filter(Document.id == document_id, Document.is_deleted == False).first()
        if not document:
            # Document does not exist or was deleted
            return False, None, None

        # Rule 4: Owner check
        if document.owner_id == user.id:
            return True, document, "OWNER"

        # Rule 6: Admins have read/audit visibility across enterprise
        if user.role == "admin" and required_action in ("READ", "AUDIT"):
            return True, document, "ADMIN_READ"

        # Rule 5: Query authoritative DocumentPermission table
        perm = (
            db.query(DocumentPermission)
            .filter(
                DocumentPermission.document_id == document.id,
                DocumentPermission.user_id == user.id
            )
            .first()
        )

        # If user has explicit OWNER permission (Co-Owner), allow all operations except primary deletion
        if perm and perm.permission == "OWNER":
            if required_action in ("READ", "EDIT", "SHARE", "MANAGE_PERMISSIONS"):
                return True, document, "OWNER"
            elif required_action == "DELETE":
                # Only primary owner or admin can delete
                pass

        # Owner-only actions: Viewers and Editors can NEVER delete, share, or manage permissions
        if required_action in ("DELETE", "SHARE", "MANAGE_PERMISSIONS"):
            AuditService.log_event(
                db=db,
                action="ACCESS_DENIED",
                resource_type="DOCUMENT",
                resource_id=document_id,
                outcome="DENIED",
                actor_id=user.id,
                actor_email=user.email,
                ip_address=ip_address,
                user_agent=user_agent,
                metadata={"reason": "Action requires document ownership", "required_action": required_action}
            )
            return False, document, None

        if not perm:
            # Access is denied (or was just revoked!)
            AuditService.log_event(
                db=db,
                action="ACCESS_DENIED",
                resource_type="DOCUMENT",
                resource_id=document_id,
                outcome="DENIED",
                actor_id=user.id,
                actor_email=user.email,
                ip_address=ip_address,
                user_agent=user_agent,
                metadata={"reason": "No active permission found", "required_action": required_action}
            )
            return False, document, None

        # Validate permission level
        if required_action == "READ":
            if perm.permission in ("READ", "EDIT", "OWNER"):
                return True, document, perm.permission
        elif required_action == "EDIT":
            if perm.permission in ("EDIT", "OWNER"):
                return True, document, "EDIT"
            else:
                AuditService.log_event(
                    db=db,
                    action="ACCESS_DENIED",
                    resource_type="DOCUMENT",
                    resource_id=document_id,
                    outcome="DENIED",
                    actor_id=user.id,
                    actor_email=user.email,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    metadata={"reason": "Insufficient privilege: EDIT required but user has READ only", "required_action": required_action}
                )
                return False, document, None

        # Default Deny
        AuditService.log_event(
            db=db,
            action="ACCESS_DENIED",
            resource_type="DOCUMENT",
            resource_id=document_id,
            outcome="DENIED",
            actor_id=user.id,
            actor_email=user.email,
            ip_address=ip_address,
            user_agent=user_agent,
            metadata={"reason": "Default-deny policy reached", "required_action": required_action}
        )
        return False, document, None


def require_document_access(
    db: Session,
    user: User,
    document_id: str,
    action: str,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> Tuple[Document, str]:
    """
    Helper that executes check_document_access and raises 404 or 403 on denial.
    Prevents existence disclosure for unauthorized users if document not shared.
    """
    authorized, document, eff_perm = AuthorizationEngine.check_document_access(
        db=db,
        user=user,
        document_id=document_id,
        required_action=action,
        ip_address=ip_address,
        user_agent=user_agent
    )

    if not document:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found."
        )

    if not authorized:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: You do not have permission to perform this action."
        )

    return document, eff_perm
