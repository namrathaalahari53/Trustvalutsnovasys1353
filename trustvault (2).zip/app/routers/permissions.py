"""
TrustVault Permissions Router
Handles document sharing, role assignment (READ/EDIT), permission modification,
and immediate revocation.
Enforces that only the document owner can grant, modify, or revoke permissions.
"""
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from app.core.csrf import check_csrf
from app.core.permissions import require_document_access
from app.core.sessions import get_current_user
from app.database.session import get_db
from app.models.document import Document
from app.models.permission import DocumentPermission
from app.models.user import User
from app.schemas.permission import (
    PermissionGrantRequest,
    PermissionUpdateRequest,
    PermissionResponse,
    PermissionListResponse,
    TransferOwnerRequest,
)
from app.services.audit_service import AuditService

router = APIRouter(tags=["Permissions"])


@router.post("/api/documents/{document_id}/permissions", response_model=PermissionResponse, status_code=status.HTTP_201_CREATED)
def grant_permission(
    document_id: str,
    req: PermissionGrantRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Authorize: Must be OWNER to grant permissions
    doc, _ = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="SHARE",
        ip_address=ip,
        user_agent=ua
    )

    # Look up target user
    target_user = db.query(User).filter(User.email == req.user_email.lower()).first()
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with email '{req.user_email}' does not exist."
        )

    if target_user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot grant sharing permissions to yourself (you are the document owner)."
        )

    # Check if permission already exists
    existing = (
        db.query(DocumentPermission)
        .filter(
            DocumentPermission.document_id == doc.id,
            DocumentPermission.user_id == target_user.id
        )
        .first()
    )

    if existing:
        # Update existing permission
        old_perm = existing.permission
        existing.permission = req.permission
        existing.granted_by = current_user.id
        db.commit()
        db.refresh(existing)

        AuditService.log_event(
            db=db,
            action="PERMISSION_MODIFY",
            resource_type="PERMISSION",
            resource_id=existing.id,
            outcome="SUCCESS",
            actor_id=current_user.id,
            actor_email=current_user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={
                "document_id": doc.id,
                "document_title": doc.title,
                "target_user_id": target_user.id,
                "target_user_email": target_user.email,
                "old_permission": old_perm,
                "new_permission": req.permission,
            }
        )
        perm_obj = existing
    else:
        new_perm = DocumentPermission(
            document_id=doc.id,
            user_id=target_user.id,
            permission=req.permission,
            granted_by=current_user.id,
        )
        db.add(new_perm)
        db.commit()
        db.refresh(new_perm)

        AuditService.log_event(
            db=db,
            action="PERMISSION_GRANT",
            resource_type="PERMISSION",
            resource_id=new_perm.id,
            outcome="SUCCESS",
            actor_id=current_user.id,
            actor_email=current_user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={
                "document_id": doc.id,
                "document_title": doc.title,
                "target_user_id": target_user.id,
                "target_user_email": target_user.email,
                "permission": req.permission,
            }
        )
        perm_obj = new_perm

    resp = PermissionResponse.model_validate(perm_obj)
    resp.user_email = target_user.email
    resp.user_username = target_user.username
    return resp


@router.get("/api/documents/{document_id}/permissions", response_model=PermissionListResponse)
def list_document_permissions(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    # Authorize: Must be OWNER to view document permissions list
    doc, _ = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="MANAGE_PERMISSIONS",
        ip_address=ip,
        user_agent=ua
    )

    perms = (
        db.query(DocumentPermission)
        .filter(DocumentPermission.document_id == doc.id)
        .order_by(DocumentPermission.created_at.desc())
        .all()
    )

    results = []
    for p in perms:
        item = PermissionResponse.model_validate(p)
        item.user_email = p.user.email if p.user else "Unknown"
        item.user_username = p.user.username if p.user else "Unknown"
        results.append(item)

    return PermissionListResponse(total=len(results), items=results)


@router.patch("/api/permissions/{permission_id}", response_model=PermissionResponse)
def update_permission(
    permission_id: str,
    req: PermissionUpdateRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    perm = db.query(DocumentPermission).filter(DocumentPermission.id == permission_id).first()
    if not perm:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Permission not found.")

    # Must be owner of the document to update permissions
    doc = db.query(Document).filter(Document.id == perm.document_id, Document.is_deleted == False).first()
    if not doc or doc.owner_id != current_user.id:
        AuditService.log_event(
            db=db,
            action="ACCESS_DENIED",
            resource_type="PERMISSION",
            resource_id=permission_id,
            outcome="DENIED",
            actor_id=current_user.id,
            actor_email=current_user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Only the document owner can update permissions"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: Only the document owner can modify permissions."
        )

    old_perm = perm.permission
    perm.permission = req.permission
    db.commit()
    db.refresh(perm)

    AuditService.log_event(
        db=db,
        action="PERMISSION_MODIFY",
        resource_type="PERMISSION",
        resource_id=perm.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "document_id": doc.id,
            "target_user_id": perm.user_id,
            "target_user_email": perm.user.email if perm.user else "",
            "old_permission": old_perm,
            "new_permission": req.permission,
        }
    )

    resp = PermissionResponse.model_validate(perm)
    resp.user_email = perm.user.email if perm.user else "Unknown"
    resp.user_username = perm.user.username if perm.user else "Unknown"
    return resp


@router.delete("/api/permissions/{permission_id}")
def revoke_permission(
    permission_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Immediate Permission Revocation.
    Deletes the permission record directly from the database and logs the revocation audit event.
    Any subsequent attempt by the target user to read, download, or edit the document is blocked immediately.
    """
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    perm = db.query(DocumentPermission).filter(DocumentPermission.id == permission_id).first()
    if not perm:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Permission record not found.")

    doc = db.query(Document).filter(Document.id == perm.document_id, Document.is_deleted == False).first()
    if not doc or doc.owner_id != current_user.id:
        AuditService.log_event(
            db=db,
            action="ACCESS_DENIED",
            resource_type="PERMISSION",
            resource_id=permission_id,
            outcome="DENIED",
            actor_id=current_user.id,
            actor_email=current_user.email,
            ip_address=ip,
            user_agent=ua,
            metadata={"reason": "Only the document owner can revoke permissions"}
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: Only the document owner can revoke permissions."
        )

    target_user_id = perm.user_id
    target_user_email = perm.user.email if perm.user else "Unknown"
    revoked_level = perm.permission

    db.delete(perm)
    db.commit()

    AuditService.log_event(
        db=db,
        action="PERMISSION_REVOKE",
        resource_type="PERMISSION",
        resource_id=permission_id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "document_id": doc.id,
            "document_title": doc.title,
            "revoked_user_id": target_user_id,
            "revoked_user_email": target_user_email,
            "revoked_permission": revoked_level,
        }
    )

    return {"message": "Permission successfully revoked. Target user can no longer access this document."}


@router.post("/api/documents/{document_id}/transfer-owner")
def transfer_document_ownership(
    document_id: str,
    req: TransferOwnerRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Transfer primary document ownership to another active user.
    Only the document owner or an admin can transfer ownership.
    """
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    doc, _ = require_document_access(
        db=db,
        user=current_user,
        document_id=document_id,
        action="SHARE",
        ip_address=ip,
        user_agent=ua
    )

    if doc.owner_id != current_user.id and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the primary document owner or an administrator can transfer document ownership."
        )

    target_user = db.query(User).filter(User.email == req.new_owner_email.lower(), User.is_active == True).first()
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Active user with email '{req.new_owner_email}' not found."
        )

    if target_user.id == doc.owner_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="The specified user is already the primary owner."
        )

    old_owner_id = doc.owner_id
    doc.owner_id = target_user.id

    # Give old owner OWNER permission so they retain co-ownership unless explicitly revoked
    existing_old_owner_perm = db.query(DocumentPermission).filter(
        DocumentPermission.document_id == doc.id,
        DocumentPermission.user_id == old_owner_id
    ).first()
    if not existing_old_owner_perm:
        db.add(DocumentPermission(
            document_id=doc.id,
            user_id=old_owner_id,
            permission="OWNER",
            granted_by=current_user.id
        ))

    db.commit()
    db.refresh(doc)

    AuditService.log_event(
        db=db,
        action="DOCUMENT_OWNERSHIP_TRANSFER",
        resource_type="DOCUMENT",
        resource_id=doc.id,
        outcome="SUCCESS",
        actor_id=current_user.id,
        actor_email=current_user.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "document_id": doc.id,
            "document_title": doc.title,
            "previous_owner_id": old_owner_id,
            "new_owner_id": target_user.id,
            "new_owner_email": target_user.email
        }
    )

    return {"message": f"Ownership of '{doc.title}' successfully transferred to {target_user.email}."}

