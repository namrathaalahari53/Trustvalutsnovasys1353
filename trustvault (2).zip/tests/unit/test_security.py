"""
Unit tests for security utilities
"""
from app.core.security import (
    hash_password,
    verify_password,
    validate_password_strength,
    generate_secure_token,
    hash_token,
    canonical_json_string,
    compute_sha256_bytes,
)


def test_password_strength_validation():
    # Too short
    valid, msg = validate_password_strength("Short1!")
    assert not valid
    assert "8 characters" in msg

    # Missing uppercase
    valid, msg = validate_password_strength("lowercase123!")
    assert not valid
    assert "uppercase" in msg

    # Missing lowercase
    valid, msg = validate_password_strength("UPPERCASE123!")
    assert not valid
    assert "lowercase" in msg

    # Missing digit
    valid, msg = validate_password_strength("NoDigitsHere!")
    assert not valid
    assert "digit" in msg

    # Missing special character
    valid, msg = validate_password_strength("NoSpecial1234")
    assert not valid
    assert "special character" in msg

    # Valid password
    valid, msg = validate_password_strength("TrustVault#2026Secure")
    assert valid
    assert msg == ""


def test_argon2id_hashing():
    pw = "Super$ecretP@ssw0rd!"
    h1 = hash_password(pw)
    assert h1.startswith("$argon2id$")
    assert verify_password(pw, h1) is True
    assert verify_password("WrongPassword!", h1) is False


def test_token_generation_and_hashing():
    t1 = generate_secure_token(32)
    t2 = generate_secure_token(32)
    assert t1 != t2
    h1 = hash_token(t1)
    h2 = hash_token(t1)
    assert h1 == h2  # deterministic
    assert len(h1) == 64


def test_canonical_json_deterministic():
    obj1 = {"b": 2, "a": 1, "c": {"y": 20, "x": 10}}
    obj2 = {"c": {"x": 10, "y": 20}, "a": 1, "b": 2}
    s1 = canonical_json_string(obj1)
    s2 = canonical_json_string(obj2)
    assert s1 == s2
    assert s1 == '{"a":1,"b":2,"c":{"x":10,"y":20}}'
