"""
Security Tests: Insecure Direct Object References (IDOR) & Privilege Escalation Defenses
Verifies that User A cannot read, download, update, delete, or share User B's documents.
"""
import io


def test_idor_protection_between_users(client):
    # 1. Register User A (Alice)
    r_a = client.post("/api/auth/register", json={
        "email": "alice_idor@trustvault.local",
        "username": "alice_idor",
        "password": "Password#2026Alice!",
    })
    csrf_a = r_a.json()["csrf_token"]

    # Alice uploads a private document
    pdf_content = b"%PDF-1.4\n1 0 obj\n<< /Data (Alice Secret Plan) >>\nendobj\ntrailer\n<<>>\n%%EOF"
    r_upload = client.post(
        "/api/documents",
        data={"title": "Alice Private Roadmap"},
        files={"file": ("roadmap.pdf", io.BytesIO(pdf_content), "application/pdf")},
        headers={"X-CSRF-Token": csrf_a}
    )
    assert r_upload.status_code == 201
    doc_a_id = r_upload.json()["id"]

    # 2. Register User B (Bob) in a separate session
    client.cookies.clear()
    r_b = client.post("/api/auth/register", json={
        "email": "bob_idor@trustvault.local",
        "username": "bob_idor",
        "password": "Password#2026Bob!",
    })
    csrf_b = r_b.json()["csrf_token"]

    # Bob attempts IDOR Read on Alice's document
    r_read = client.get(f"/api/documents/{doc_a_id}")
    assert r_read.status_code in (403, 404)
    assert "access denied" in r_read.text.lower() or "not found" in r_read.text.lower()

    # Bob attempts IDOR Download on Alice's document
    r_down = client.get(f"/api/documents/{doc_a_id}/download")
    assert r_down.status_code in (403, 404)

    # Bob attempts IDOR Update on Alice's document
    r_update = client.patch(
        f"/api/documents/{doc_a_id}",
        json={"title": "Hacked Title"},
        headers={"X-CSRF-Token": csrf_b}
    )
    assert r_update.status_code in (403, 404)

    # Bob attempts IDOR Delete on Alice's document
    r_del = client.delete(f"/api/documents/{doc_a_id}", headers={"X-CSRF-Token": csrf_b})
    assert r_del.status_code in (403, 404)

    # Bob attempts to grant permission on Alice's document
    r_grant = client.post(
        f"/api/documents/{doc_a_id}/permissions",
        json={"user_email": "attacker@evil.com", "permission": "EDIT"},
        headers={"X-CSRF-Token": csrf_b}
    )
    assert r_grant.status_code in (403, 404)

    # Bob attempts to guess random UUID
    r_random = client.get("/api/documents/00000000-0000-0000-0000-000000000000")
    assert r_random.status_code == 404


def test_viewer_cannot_escalate_to_owner_or_edit_read_only(client):
    # Alice registers and uploads doc
    client.post("/api/auth/register", json={
        "email": "owner_perm@trustvault.local",
        "username": "owner_perm",
        "password": "Password#2026Owner!",
    })

    # Register Bob first so he can be granted access
    client.cookies.clear()
    client.post("/api/auth/register", json={
        "email": "viewer_bob@trustvault.local",
        "username": "viewer_bob",
        "password": "Password#2026Viewer!",
    })

    # Switch back to Alice
    client.cookies.clear()
    r_login_a = client.post("/api/auth/login", json={
        "email": "owner_perm@trustvault.local",
        "password": "Password#2026Owner!",
    })
    csrf_a = r_login_a.json()["csrf_token"]

    pdf_content = b"%PDF-1.4\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF"
    r_up = client.post(
        "/api/documents",
        data={"title": "Contract Proposal"},
        files={"file": ("contract.pdf", io.BytesIO(pdf_content), "application/pdf")},
        headers={"X-CSRF-Token": csrf_a}
    )
    doc_id = r_up.json()["id"]

    # Alice grants Bob READ ONLY permission
    r_share = client.post(
        f"/api/documents/{doc_id}/permissions",
        json={"user_email": "viewer_bob@trustvault.local", "permission": "READ"},
        headers={"X-CSRF-Token": csrf_a}
    )
    assert r_share.status_code == 201

    # Switch to Bob
    client.cookies.clear()
    r_login_b = client.post("/api/auth/login", json={
        "email": "viewer_bob@trustvault.local",
        "password": "Password#2026Viewer!",
    })
    csrf_b = r_login_b.json()["csrf_token"]

    # Bob can READ and DOWNLOAD
    assert client.get(f"/api/documents/{doc_id}").status_code == 200
    assert client.get(f"/api/documents/{doc_id}/download").status_code == 200

    # Bob CANNOT EDIT (he has READ only)
    r_edit = client.patch(
        f"/api/documents/{doc_id}",
        json={"title": "Tampered Contract"},
        headers={"X-CSRF-Token": csrf_b}
    )
    assert r_edit.status_code == 403

    # Bob CANNOT DELETE (strictly owner-only)
    r_del = client.delete(f"/api/documents/{doc_id}", headers={"X-CSRF-Token": csrf_b})
    assert r_del.status_code == 403

    # Bob CANNOT SHARE with someone else
    r_subshare = client.post(
        f"/api/documents/{doc_id}/permissions",
        json={"user_email": "thirdparty@trustvault.local", "permission": "READ"},
        headers={"X-CSRF-Token": csrf_b}
    )
    assert r_subshare.status_code == 403
