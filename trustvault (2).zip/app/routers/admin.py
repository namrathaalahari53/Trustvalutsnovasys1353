"""
TrustVault Administrator Router
Allows administrators to manage accounts, deactivate/reactivate users,
inspect system-wide security activity, and review system stats.
"""
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.csrf import check_csrf
from app.core.sessions import get_current_admin, SessionManager
from app.database.session import get_db
from app.models.user import User
from app.models.document import Document
from app.models.session import UserSession
from app.models.audit_event import AuditEvent
from app.schemas.admin import (
    AdminUserResponse,
    AdminUserStatusUpdateRequest,
    SystemStatsResponse,
)
from app.schemas.audit import AuditListResponse, AuditEventResponse
from app.services.audit_service import AuditService
import json

router = APIRouter(prefix="/api/admin", tags=["Administration"])


@router.get("/users", response_model=List[AdminUserResponse])
def list_users(
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """List all user accounts in the enterprise."""
    users = db.query(User).order_by(User.created_at.desc()).all()
    results = []

    for u in users:
        docs_count = db.query(Document).filter(Document.owner_id == u.id, Document.is_deleted == False).count()
        sessions_count = db.query(UserSession).filter(UserSession.user_id == u.id, UserSession.is_active == True).count()
        item = AdminUserResponse(
            id=u.id,
            email=u.email,
            username=u.username,
            role=u.role,
            is_active=u.is_active,
            created_at=u.created_at,
            documents_count=docs_count,
            active_sessions_count=sessions_count,
        )
        results.append(item)

    return results


@router.patch("/users/{user_id}/status", response_model=AdminUserResponse)
def update_user_status(
    user_id: str,
    req: AdminUserStatusUpdateRequest,
    request: Request,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """
    Activate or deactivate user accounts.
    Deactivation immediately terminates all active sessions for the user.
    """
    check_csrf(request)
    ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("User-Agent", "Unknown")

    if user_id == admin.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Administrators cannot deactivate their own account."
        )

    target_user = db.query(User).filter(User.id == user_id).first()
    if not target_user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")

    old_status = target_user.is_active
    target_user.is_active = req.is_active

    # If deactivating, invalidate all sessions immediately
    terminated_sessions = 0
    if not req.is_active:
        terminated_sessions = SessionManager.invalidate_all_user_sessions(db, target_user.id)

    db.commit()
    db.refresh(target_user)

    action_name = "USER_DEACTIVATED" if not req.is_active else "USER_ACTIVATED"
    AuditService.log_event(
        db=db,
        action=action_name,
        resource_type="USER",
        resource_id=target_user.id,
        outcome="SUCCESS",
        actor_id=admin.id,
        actor_email=admin.email,
        ip_address=ip,
        user_agent=ua,
        metadata={
            "target_user_id": target_user.id,
            "target_user_email": target_user.email,
            "old_status": old_status,
            "new_status": req.is_active,
            "sessions_terminated": terminated_sessions,
        }
    )

    docs_count = db.query(Document).filter(Document.owner_id == target_user.id, Document.is_deleted == False).count()
    sessions_count = db.query(UserSession).filter(UserSession.user_id == target_user.id, UserSession.is_active == True).count()

    return AdminUserResponse(
        id=target_user.id,
        email=target_user.email,
        username=target_user.username,
        role=target_user.role,
        is_active=target_user.is_active,
        created_at=target_user.created_at,
        documents_count=docs_count,
        active_sessions_count=sessions_count,
    )


@router.get("/activity", response_model=AuditListResponse)
def get_security_activity(
    limit: int = 100,
    offset: int = 0,
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """
    Review security-relevant operations and access anomalies across the system.
    """
    security_actions = [
        "LOGIN_FAILURE", "LOGIN_RATE_LIMITED", "ACCESS_DENIED",
        "PERMISSION_REVOKE", "USER_DEACTIVATED", "PASSWORD_RESET_FAILURE",
        "DOCUMENT_UPLOAD_FAILED", "AUDIT_VERIFICATION_PERFORMED"
    ]

    query = db.query(AuditEvent).filter(
        (AuditEvent.outcome.in_(["FAILURE", "DENIED"])) | (AuditEvent.action.in_(security_actions))
    )

    total = query.count()
    events = query.order_by(AuditEvent.sequence_number.desc()).offset(offset).limit(limit).all()

    items = []
    for ev in events:
        try:
            meta = json.loads(ev.metadata_json)
        except Exception:
            meta = {}
        item = AuditEventResponse(
            id=ev.id,
            sequence_number=ev.sequence_number,
            actor_id=ev.actor_id,
            actor_email=ev.actor_email,
            action=ev.action,
            resource_type=ev.resource_type,
            resource_id=ev.resource_id,
            outcome=ev.outcome,
            ip_address=ev.ip_address,
            user_agent=ev.user_agent,
            metadata=meta,
            timestamp_utc=ev.timestamp_utc,
            previous_hash=ev.previous_hash,
            current_hash=ev.current_hash,
        )
        items.append(item)

    return AuditListResponse(total=total, items=items)


@router.get("/stats", response_model=SystemStatsResponse)
def get_system_stats(
    admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    """Get system-wide metrics and audit integrity status."""
    total_users = db.query(User).count()
    active_users = db.query(User).filter(User.is_active == True).count()
    disabled_users = db.query(User).filter(User.is_active == False).count()
    total_docs = db.query(Document).filter(Document.is_deleted == False).count()
    total_audit = db.query(AuditEvent).count()

    # Fast verification check
    chain_check = AuditService.verify_chain(db)
    denied_events = db.query(AuditEvent).filter(AuditEvent.outcome == "DENIED").count()

    return SystemStatsResponse(
        total_users=total_users,
        active_users=active_users,
        disabled_users=disabled_users,
        total_documents=total_docs,
        total_audit_events=total_audit,
        audit_chain_valid=chain_check["is_valid"],
        recent_denied_events_count=denied_events,
    )
