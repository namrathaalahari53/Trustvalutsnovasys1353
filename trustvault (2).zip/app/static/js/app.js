/**
 * TrustVault Enterprise Client Application
 * Handles authentication, reactive UI updates, document actions,
 * permission management, and audit verification.
 */

const AppState = {
  user: null,
  sessionToken: localStorage.getItem('tv_session_token') || null,
  csrfToken: localStorage.getItem('tv_csrf_token') || null,
  activeTab: 'dashboard',
  currentDocId: null,
  documents: [],
  auditEvents: [],
  users: [],
};

// Helper: Format Dates in UTC
function formatDate(isoStr) {
  if (!isoStr) return '—';
  try {
    const d = new Date(isoStr);
    return d.toLocaleString() + ' UTC';
  } catch (e) {
    return isoStr;
  }
}

// Helper: Format Bytes to human readable
function formatBytes(bytes, decimals = 1) {
  if (!+bytes) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

// Toast Notification
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const bgMap = {
    success: 'bg-success',
    danger: 'bg-danger',
    warning: 'bg-warning text-dark',
    info: 'bg-primary',
  };

  const toastEl = document.createElement('div');
  toastEl.className = `toast align-items-center text-white ${bgMap[type] || 'bg-primary'} border-0 mb-2 show`;
  toastEl.setAttribute('role', 'alert');
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>
  `;
  container.appendChild(toastEl);
  setTimeout(() => {
    toastEl.remove();
  }, 4500);
}

// Unified API Caller with CSRF token, session token & credentials
async function apiCall(endpoint, options = {}) {
  const headers = { ...options.headers };

  // Attach session token in headers for seamless iframe & proxy support
  if (AppState.sessionToken) {
    headers['Authorization'] = `Bearer ${AppState.sessionToken}`;
    headers['X-Session-Token'] = AppState.sessionToken;
  }

  if (AppState.csrfToken && ['POST', 'PATCH', 'DELETE', 'PUT'].includes((options.method || 'GET').toUpperCase())) {
    headers['X-CSRF-Token'] = AppState.csrfToken;
  }

  // Do not set Content-Type for FormData
  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
    credentials: 'include',
  });

  if (response.status === 401) {
    const wasLoggedIn = Boolean(AppState.user);
    AppState.user = null;
    AppState.sessionToken = null;
    localStorage.removeItem('tv_session_token');

    if (!endpoint.includes('/api/auth/login') && !endpoint.includes('/api/auth/register')) {
      showAuthView('login');
      // Only display session expired toast if the user was actively in a session
      if (wasLoggedIn && !endpoint.includes('/api/auth/me')) {
        showToast('Your session has expired. Please sign in again.', 'warning');
      }
      throw new Error('Session expired.');
    }
  }

  const contentType = response.headers.get('content-type') || '';
  if (!response.ok) {
    let errMessage = 'Request failed';
    if (contentType.includes('application/json')) {
      const errData = await response.json();
      errMessage = errData.detail || errData.message || JSON.stringify(errData);
    } else {
      errMessage = await response.text();
    }
    throw new Error(errMessage);
  }

  if (contentType.includes('application/json')) {
    return await response.json();
  }
  return response;
}

// Helper: Download URL with auth token for direct browser links
function getDownloadUrl(docId) {
  const token = AppState.sessionToken;
  return `/api/documents/${docId}/download${token ? '?token=' + encodeURIComponent(token) : ''}`;
}

// Check session on startup
async function checkAuthStatus() {
  // If no saved token, show login screen cleanly without triggering error
  if (!AppState.sessionToken) {
    showAuthView('login');
    return;
  }

  try {
    const res = await apiCall('/api/auth/me');
    AppState.user = res.user;
    if (res.csrf_token) {
      AppState.csrfToken = res.csrf_token;
      localStorage.setItem('tv_csrf_token', res.csrf_token);
    }
    renderAppLayout();
    showTab('dashboard');
  } catch (err) {
    AppState.user = null;
    AppState.sessionToken = null;
    localStorage.removeItem('tv_session_token');
    showAuthView('login');
  }
}

// Demo Role Selector
function selectDemoRole(role) {
  const emailInput = document.getElementById('login-email');
  const passInput = document.getElementById('login-password');
  const hint = document.getElementById('demo-role-hint');

  if (role === 'owner') {
    emailInput.value = 'alice@trustvault.local';
    passInput.value = 'TrustVault2026!Alice#';
    if (hint) {
      hint.innerHTML = '<span class="text-info fw-bold">👑 Selected: Document Owner (Alice)</span> — Full privileges to upload, share, add co-owners, and transfer ownership.';
    }
    showToast('Loaded Document Owner credentials (alice@trustvault.local)', 'info');
  } else if (role === 'admin') {
    emailInput.value = 'admin@trustvault.local';
    passInput.value = 'TrustVault2026!Admin#';
    if (hint) {
      hint.innerHTML = '<span class="text-warning fw-bold">🛡️ Selected: Administrator</span> — Enterprise oversight, user management, and security audit.';
    }
    showToast('Loaded Administrator credentials (admin@trustvault.local)', 'warning');
  } else if (role === 'viewer') {
    emailInput.value = 'bob@trustvault.local';
    passInput.value = 'TrustVault2026!Bob#';
    if (hint) {
      hint.innerHTML = '<span class="text-light fw-bold">👁️ Selected: Viewer / Collaborator (Bob)</span> — Recipient of shared documents and co-owner.';
    }
    showToast('Loaded Viewer credentials (bob@trustvault.local)', 'secondary');
  }
}

// Layout Switcher
function showAuthView(viewName = 'login') {
  document.getElementById('auth-layout').classList.remove('d-none');
  document.getElementById('app-layout').classList.add('d-none');

  document.getElementById('auth-login-view').classList.add('d-none');
  document.getElementById('auth-register-view').classList.add('d-none');
  document.getElementById('auth-forgot-view').classList.add('d-none');
  document.getElementById('auth-reset-view').classList.add('d-none');

  if (viewName === 'login') {
    document.getElementById('auth-login-view').classList.remove('d-none');
  } else if (viewName === 'register') {
    document.getElementById('auth-register-view').classList.remove('d-none');
  } else if (viewName === 'forgot') {
    document.getElementById('auth-forgot-view').classList.remove('d-none');
  } else if (viewName === 'reset') {
    document.getElementById('auth-reset-view').classList.remove('d-none');
  }
}

function renderAppLayout() {
  document.getElementById('auth-layout').classList.add('d-none');
  document.getElementById('app-layout').classList.remove('d-none');

  if (!AppState.user) return;

  document.getElementById('user-display-name').textContent = AppState.user.username;
  document.getElementById('user-display-email').textContent = AppState.user.email;
  
  const roleBadge = document.getElementById('user-role-badge');
  roleBadge.textContent = AppState.user.role.toUpperCase();
  roleBadge.className = `badge ${AppState.user.role === 'admin' ? 'badge-admin' : 'badge-owner'}`;

  // Admin menu visibility
  const adminMenuItems = document.querySelectorAll('.admin-only');
  adminMenuItems.forEach(el => {
    if (AppState.user.role === 'admin') {
      el.classList.remove('d-none');
    } else {
      el.classList.add('d-none');
    }
  });
}

// Tab Switcher
function showTab(tabName) {
  AppState.activeTab = tabName;

  // Update navigation styling
  document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
    link.classList.remove('active');
    if (link.dataset.tab === tabName) {
      link.classList.add('active');
    }
  });

  // Hide all tab panes
  document.querySelectorAll('.tab-pane-view').forEach(pane => {
    pane.classList.add('d-none');
  });

  const targetPane = document.getElementById(`tab-${tabName}`);
  if (targetPane) {
    targetPane.classList.remove('d-none');
  }

  // Load tab data
  if (tabName === 'dashboard') loadDashboard();
  else if (tabName === 'my-documents') loadMyDocuments();
  else if (tabName === 'upload') resetUploadForm();
  else if (tabName === 'shared-with-me') loadSharedDocuments();
  else if (tabName === 'audit-history') loadAuditHistory();
  else if (tabName === 'security-audit') runLiveSecurityAudit();
  else if (tabName === 'admin-dashboard') loadAdminDashboard();
  else if (tabName === 'user-management') loadUserManagement();
  else if (tabName === 'security-activity') loadSecurityActivity();
  else if (tabName === 'profile') loadProfile();
}

// ---------------- DASHBOARD ----------------
async function loadDashboard() {
  try {
    const [docsRes, auditRes] = await Promise.all([
      apiCall('/api/documents'),
      apiCall('/api/audit?limit=5')
    ]);

    const owned = docsRes.items.filter(d => d.is_owner);
    const shared = docsRes.items.filter(d => !d.is_owner);

    document.getElementById('dash-owned-count').textContent = owned.length;
    document.getElementById('dash-shared-count').textContent = shared.length;
    document.getElementById('dash-audit-count').textContent = auditRes.total;

    // Recent activity list
    const actContainer = document.getElementById('dash-recent-activity');
    if (actContainer) {
      if (auditRes.items.length === 0) {
        actContainer.innerHTML = '<p class="text-muted small mb-0">No recent activity recorded.</p>';
      } else {
        actContainer.innerHTML = auditRes.items.map(ev => `
          <div class="d-flex align-items-center justify-content-between py-2 border-bottom border-secondary">
            <div>
              <span class="badge ${ev.outcome === 'SUCCESS' ? 'bg-success' : 'badge-denied'} me-2">${ev.action}</span>
              <span class="small text-light">${ev.actor_email || 'System'}</span>
            </div>
            <div class="small text-muted">${formatDate(ev.timestamp_utc)}</div>
          </div>
        `).join('');
      }
    }
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

// ---------------- MY DOCUMENTS ----------------
async function loadMyDocuments() {
  const container = document.getElementById('my-docs-container');
  container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';

  try {
    const search = document.getElementById('my-docs-search')?.value || '';
    const ext = document.getElementById('my-docs-ext-filter')?.value || '';
    
    let url = `/api/documents?scope=owned`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (ext) url += `&filter_type=${encodeURIComponent(ext)}`;

    const res = await apiCall(url);
    AppState.documents = res.items;

    if (res.items.length === 0) {
      container.innerHTML = `
        <div class="text-center py-5 border border-dashed rounded p-4">
          <i class="bi bi-folder2-open display-4 text-muted mb-3"></i>
          <h5>No documents found</h5>
          <p class="text-muted small">Upload your confidential documents to securely store and share them.</p>
          <button class="btn btn-primary btn-sm mt-2" onclick="showTab('upload')">
            <i class="bi bi-upload me-1"></i> Upload Document
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="row g-3">
        ${res.items.map(doc => renderDocumentCard(doc)).join('')}
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
}

function renderDocumentCard(doc) {
  const ext = doc.original_filename.split('.').pop().toLowerCase();
  let typeClass = 'type-txt';
  if (['pdf'].includes(ext)) typeClass = 'type-pdf';
  else if (['doc', 'docx'].includes(ext)) typeClass = 'type-docx';
  else if (['xls', 'xlsx', 'csv'].includes(ext)) typeClass = 'type-xlsx';
  else if (['png', 'jpg', 'jpeg'].includes(ext)) typeClass = 'type-img';

  return `
    <div class="col-md-6 col-lg-4">
      <div class="tv-card doc-card h-100 p-3 d-flex flex-column justify-content-between">
        <div>
          <div class="d-flex align-items-start justify-content-between mb-2">
            <div class="d-flex align-items-center gap-2">
              <div class="file-type-icon ${typeClass}">${ext}</div>
              <div>
                <h6 class="mb-0 text-truncate" style="max-width: 170px;" title="${doc.title}">${doc.title}</h6>
                <small class="text-muted">${formatBytes(doc.file_size)}</small>
              </div>
            </div>
            <span class="badge ${doc.is_owner ? 'badge-owner' : (doc.current_user_permission === 'EDIT' ? 'badge-edit' : 'badge-read')}">
              ${doc.is_owner ? 'OWNER' : doc.current_user_permission}
            </span>
          </div>
          <p class="small text-muted mb-3 text-truncate">${doc.description || 'No description'}</p>
          <div class="d-flex align-items-center justify-content-between text-muted small mb-3">
            <span>Uploaded:</span>
            <span>${formatDate(doc.created_at)}</span>
          </div>
        </div>

        <div class="d-flex align-items-center gap-1 pt-2 border-top border-secondary">
          <button class="btn btn-sm btn-outline-info flex-fill" onclick="openDocumentDetailsModal('${doc.id}')" title="Details & Audit History">
            <i class="bi bi-info-circle"></i> Details
          </button>
          ${doc.is_owner ? `
            <button class="btn btn-sm btn-outline-primary flex-fill" onclick="openManagePermissionsModal('${doc.id}')" title="Manage Permissions">
              <i class="bi bi-people"></i> Share
            </button>
          ` : ''}
          <a class="btn btn-sm btn-outline-success flex-fill" href="${getDownloadUrl(doc.id)}" download title="Download File">
            <i class="bi bi-download"></i>
          </a>
          ${(doc.is_owner || doc.current_user_permission === 'EDIT') ? `
            <button class="btn btn-sm btn-outline-secondary" onclick="openEditDocumentModal('${doc.id}')" title="Edit Metadata">
              <i class="bi bi-pencil"></i>
            </button>
          ` : ''}
          ${doc.is_owner ? `
            <button class="btn btn-sm btn-outline-danger" onclick="openDeleteConfirmModal('${doc.id}')" title="Delete Document">
              <i class="bi bi-trash"></i>
            </button>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

// ---------------- SHARED WITH ME ----------------
async function loadSharedDocuments() {
  const container = document.getElementById('shared-docs-container');
  container.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';

  try {
    const res = await apiCall('/api/documents?scope=shared');
    if (res.items.length === 0) {
      container.innerHTML = `
        <div class="text-center py-5 border border-dashed rounded p-4">
          <i class="bi bi-share display-4 text-muted mb-3"></i>
          <h5>No shared documents</h5>
          <p class="text-muted small">Documents explicitly shared with you by other users will appear here.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="row g-3">
        ${res.items.map(doc => renderDocumentCard(doc)).join('')}
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
}

// ---------------- UPLOAD DOCUMENT ----------------
function resetUploadForm() {
  document.getElementById('upload-form').reset();
  document.getElementById('upload-preview').classList.add('d-none');
  document.getElementById('upload-progress-container').classList.add('d-none');
}

// Handle file selection
function handleFileSelect(file) {
  if (!file) return;
  document.getElementById('upload-preview').classList.remove('d-none');
  document.getElementById('preview-filename').textContent = file.name;
  document.getElementById('preview-filesize').textContent = formatBytes(file.size);

  const titleInput = document.getElementById('upload-title');
  if (!titleInput.value) {
    titleInput.value = file.name.replace(/\.[^/.]+$/, "");
  }
}

// ---------------- DOCUMENT DETAILS MODAL ----------------
async function openDocumentDetailsModal(docId) {
  AppState.currentDocId = docId;
  const modalEl = document.getElementById('docDetailsModal');
  const modal = new bootstrap.Modal(modalEl);

  document.getElementById('details-modal-title').textContent = 'Loading Document Details...';
  document.getElementById('details-modal-content').innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>';
  modal.show();

  try {
    const [doc, auditRes] = await Promise.all([
      apiCall(`/api/documents/${docId}`),
      apiCall(`/api/audit/documents/${docId}`)
    ]);

    document.getElementById('details-modal-title').textContent = doc.title;
    document.getElementById('details-modal-content').innerHTML = `
      <div class="row g-3 mb-4">
        <div class="col-md-6">
          <div class="p-3 tv-card">
            <small class="text-muted d-block">Original Filename</small>
            <span class="fw-semibold">${doc.original_filename}</span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="p-3 tv-card">
            <small class="text-muted d-block">Owner</small>
            <span class="fw-semibold">${doc.owner_email || doc.owner_username}</span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="p-3 tv-card">
            <small class="text-muted d-block">File Size & MIME</small>
            <span>${formatBytes(doc.file_size)} • <code>${doc.mime_type}</code></span>
          </div>
        </div>
        <div class="col-md-6">
          <div class="p-3 tv-card">
            <small class="text-muted d-block">Your Access Level</small>
            <span class="badge ${doc.is_owner ? 'badge-owner' : (doc.current_user_permission === 'EDIT' ? 'badge-edit' : 'badge-read')}">
              ${doc.is_owner ? 'OWNER' : doc.current_user_permission}
            </span>
          </div>
        </div>
        <div class="col-12">
          <div class="p-3 tv-card">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <small class="text-muted">SHA-256 Checksum</small>
              <button class="btn btn-sm btn-link text-decoration-none p-0 text-info" onclick="navigator.clipboard.writeText('${doc.file_hash_sha256}'); showToast('SHA-256 copied to clipboard', 'info');">
                <i class="bi bi-clipboard"></i> Copy
              </button>
            </div>
            <code class="hash-font text-break">${doc.file_hash_sha256}</code>
          </div>
        </div>
        <div class="col-12">
          <div class="p-3 tv-card">
            <small class="text-muted d-block">Description</small>
            <span>${doc.description || '<em class="text-muted">No description provided</em>'}</span>
          </div>
        </div>
      </div>

      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="mb-0"><i class="bi bi-shield-check me-1"></i> Access & Audit Trail</h6>
        <span class="badge bg-secondary">${auditRes.total} Records</span>
      </div>

      <div class="table-responsive border rounded" style="max-height: 240px; overflow-y: auto;">
        <table class="table table-dark table-sm table-hover mb-0">
          <thead>
            <tr>
              <th>Action</th>
              <th>Actor</th>
              <th>Outcome</th>
              <th>UTC Timestamp</th>
            </tr>
          </thead>
          <tbody>
            ${auditRes.items.length === 0 ? '<tr><td colspan="4" class="text-center text-muted py-3">No audit records found</td></tr>' : ''}
            ${auditRes.items.map(ev => `
              <tr>
                <td><span class="badge ${ev.outcome === 'SUCCESS' ? 'bg-primary' : 'badge-denied'}">${ev.action}</span></td>
                <td><small>${ev.actor_email || 'Unknown'}</small></td>
                <td><small class="${ev.outcome === 'SUCCESS' ? 'text-success' : 'text-danger'}">${ev.outcome}</small></td>
                <td><small class="text-muted">${formatDate(ev.timestamp_utc)}</small></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    document.getElementById('details-download-btn').onclick = () => {
      window.location.href = getDownloadUrl(docId);
    };
  } catch (err) {
    document.getElementById('details-modal-content').innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
}

// ---------------- MANAGE PERMISSIONS MODAL ----------------
async function openManagePermissionsModal(docId) {
  AppState.currentDocId = docId;
  const modalEl = document.getElementById('managePermissionsModal');
  const modal = new bootstrap.Modal(modalEl);
  modal.show();
  await refreshPermissionsList(docId);
}

async function refreshPermissionsList(docId) {
  const container = document.getElementById('permissions-list-container');
  container.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary spinner-border-sm"></div></div>';

  try {
    const res = await apiCall(`/api/documents/${docId}/permissions`);
    if (res.items.length === 0) {
      container.innerHTML = '<p class="text-muted small text-center my-3">This document is private. No other users have been granted access.</p>';
      return;
    }

    container.innerHTML = `
      <div class="table-responsive">
        <table class="table table-dark table-sm table-hover align-middle mb-0">
          <thead>
            <tr>
              <th>Collaborator</th>
              <th>Permission Level</th>
              <th>Granted At</th>
              <th class="text-end">Action</th>
            </tr>
          </thead>
          <tbody>
            ${res.items.map(p => `
              <tr>
                <td>
                  <div class="fw-semibold small">${p.user_email}</div>
                  <div class="text-muted" style="font-size: 0.75rem;">@${p.user_username}</div>
                </td>
                <td>
                  <select class="form-select form-select-sm d-inline-block w-auto bg-dark border-secondary text-white" onchange="changePermissionRole('${p.id}', this.value)">
                    <option value="READ" ${p.permission === 'READ' ? 'selected' : ''}>READ ONLY</option>
                    <option value="EDIT" ${p.permission === 'EDIT' ? 'selected' : ''}>CAN EDIT</option>
                    <option value="OWNER" ${p.permission === 'OWNER' ? 'selected' : ''}>CO-OWNER</option>
                  </select>
                </td>
                <td class="small text-muted">${formatDate(p.created_at)}</td>
                <td class="text-end">
                  <button class="btn btn-sm btn-outline-danger" onclick="revokePermission('${p.id}', '${p.user_email}')" title="Revoke Access Immediately">
                    <i class="bi bi-x-circle me-1"></i> Revoke
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger small">${err.message}</div>`;
  }
}

async function transferOwnership(e) {
  e.preventDefault();
  const email = document.getElementById('transfer-new-owner-email').value.trim();
  const docId = AppState.currentDocId;

  if (!confirm(`Are you sure you want to transfer primary ownership of this document to ${email}?`)) {
    return;
  }

  try {
    const res = await apiCall(`/api/documents/${docId}/transfer-owner`, {
      method: 'POST',
      body: JSON.stringify({ new_owner_email: email }),
    });
    showToast(res.message || 'Ownership transferred successfully!', 'success');
    document.getElementById('transfer-new-owner-email').value = '';
    await refreshPermissionsList(docId);
    loadMyDocuments();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function grantNewPermission(e) {
  e.preventDefault();
  const email = document.getElementById('perm-user-email').value.trim();
  const permission = document.getElementById('perm-level-select').value;
  const docId = AppState.currentDocId;

  try {
    await apiCall(`/api/documents/${docId}/permissions`, {
      method: 'POST',
      body: JSON.stringify({ user_email: email, permission }),
    });
    showToast(`Access granted to ${email} as ${permission}`, 'success');
    document.getElementById('perm-user-email').value = '';
    await refreshPermissionsList(docId);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function changePermissionRole(permId, newRole) {
  try {
    await apiCall(`/api/permissions/${permId}`, {
      method: 'PATCH',
      body: JSON.stringify({ permission: newRole }),
    });
    showToast(`Permission updated to ${newRole}`, 'success');
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function revokePermission(permId, email) {
  if (!confirm(`Are you sure you want to revoke access for ${email}? Their access will be terminated immediately.`)) {
    return;
  }

  try {
    await apiCall(`/api/permissions/${permId}`, {
      method: 'DELETE',
    });
    showToast(`Access revoked for ${email}. Immediate enforcement applied.`, 'warning');
    await refreshPermissionsList(AppState.currentDocId);
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

// ---------------- EDIT METADATA MODAL ----------------
function openEditDocumentModal(docId) {
  const doc = AppState.documents.find(d => d.id === docId);
  if (!doc) return;
  AppState.currentDocId = docId;

  document.getElementById('edit-doc-title').value = doc.title;
  document.getElementById('edit-doc-desc').value = doc.description || '';

  const modal = new bootstrap.Modal(document.getElementById('editDocModal'));
  modal.show();
}

async function saveDocumentMetadata(e) {
  e.preventDefault();
  const docId = AppState.currentDocId;
  const title = document.getElementById('edit-doc-title').value.trim();
  const description = document.getElementById('edit-doc-desc').value.trim();

  try {
    await apiCall(`/api/documents/${docId}`, {
      method: 'PATCH',
      body: JSON.stringify({ title, description }),
    });
    showToast('Document metadata updated', 'success');
    bootstrap.Modal.getInstance(document.getElementById('editDocModal')).hide();
    if (AppState.activeTab === 'my-documents') loadMyDocuments();
    else if (AppState.activeTab === 'shared-with-me') loadSharedDocuments();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

// ---------------- DELETE DOCUMENT MODAL ----------------
function openDeleteConfirmModal(docId) {
  AppState.currentDocId = docId;
  const doc = AppState.documents.find(d => d.id === docId);
  document.getElementById('delete-doc-name').textContent = doc ? doc.title : 'this document';
  const modal = new bootstrap.Modal(document.getElementById('deleteDocModal'));
  modal.show();
}

async function confirmDeleteDocument() {
  const docId = AppState.currentDocId;
  try {
    await apiCall(`/api/documents/${docId}`, {
      method: 'DELETE',
    });
    showToast('Document permanently removed', 'success');
    bootstrap.Modal.getInstance(document.getElementById('deleteDocModal')).hide();
    loadMyDocuments();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

// ---------------- AUDIT HISTORY & VERIFICATION ----------------
async function loadAuditHistory() {
  const container = document.getElementById('audit-table-body');
  container.innerHTML = '<tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const action = document.getElementById('audit-action-filter')?.value || '';
    let url = `/api/audit?limit=100`;
    if (action) url += `&action=${encodeURIComponent(action)}`;

    const res = await apiCall(url);
    AppState.auditEvents = res.items;

    document.getElementById('audit-total-count').textContent = `${res.total} Events`;

    if (res.items.length === 0) {
      container.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">No audit events recorded</td></tr>';
      return;
    }

    container.innerHTML = res.items.map(ev => `
      <tr>
        <td class="fw-bold">#${ev.sequence_number}</td>
        <td>
          <span class="badge ${ev.outcome === 'SUCCESS' ? 'bg-primary' : 'badge-denied'}">${ev.action}</span>
        </td>
        <td><small>${ev.actor_email || '<em class="text-muted">Unauthenticated</em>'}</small></td>
        <td><small class="badge bg-dark border border-secondary">${ev.resource_type}</small></td>
        <td><small class="${ev.outcome === 'SUCCESS' ? 'text-success' : 'text-danger'} fw-semibold">${ev.outcome}</small></td>
        <td><small class="text-muted">${formatDate(ev.timestamp_utc)}</small></td>
        <td>
          <button class="btn btn-sm btn-outline-info py-0 px-2" onclick="showAuditEventDetail('${ev.id}')">
            <i class="bi bi-eye"></i> Hash
          </button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    container.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function showAuditEventDetail(eventId) {
  const ev = AppState.auditEvents.find(e => e.id === eventId);
  if (!ev) return;

  const modal = new bootstrap.Modal(document.getElementById('auditDetailModal'));
  document.getElementById('audit-detail-id').textContent = ev.id;
  document.getElementById('audit-detail-seq').textContent = `#${ev.sequence_number}`;
  document.getElementById('audit-detail-action').textContent = ev.action;
  document.getElementById('audit-detail-actor').textContent = ev.actor_email || 'None';
  document.getElementById('audit-detail-outcome').textContent = ev.outcome;
  document.getElementById('audit-detail-ip').textContent = ev.ip_address || '—';
  document.getElementById('audit-detail-time').textContent = formatDate(ev.timestamp_utc);
  document.getElementById('audit-detail-prev-hash').textContent = ev.previous_hash;
  document.getElementById('audit-detail-curr-hash').textContent = ev.current_hash;
  document.getElementById('audit-detail-meta').textContent = JSON.stringify(ev.metadata, null, 2);
  modal.show();
}

async function verifyAuditChainIntegrity() {
  const btn = document.getElementById('verify-chain-btn');
  const originalHtml = btn.innerHTML;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Verifying Chain...';
  btn.disabled = true;

  try {
    const res = await apiCall('/api/audit/verify', { method: 'POST' });
    const modal = new bootstrap.Modal(document.getElementById('chainVerifyModal'));

    const statusBadge = document.getElementById('verify-chain-badge');
    if (res.is_valid) {
      statusBadge.className = 'badge bg-success fs-6 p-2';
      statusBadge.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i> VALID & UNBROKEN';
    } else {
      statusBadge.className = 'badge bg-danger fs-6 p-2';
      statusBadge.innerHTML = '<i class="bi bi-shield-slash-fill me-1"></i> COMPROMISED / TAMPERED';
    }

    document.getElementById('verify-chain-count').textContent = res.total_events_verified;
    document.getElementById('verify-chain-genesis').textContent = res.genesis_hash;
    document.getElementById('verify-chain-latest').textContent = res.latest_hash;
    document.getElementById('verify-chain-time').textContent = formatDate(res.verified_at);

    const errorDiv = document.getElementById('verify-chain-error');
    if (res.error_detail) {
      errorDiv.classList.remove('d-none');
      errorDiv.textContent = `Broken at Sequence #${res.broken_at_sequence}: ${res.error_detail}`;
    } else {
      errorDiv.classList.add('d-none');
    }

    modal.show();
    if (AppState.activeTab === 'audit-history') loadAuditHistory();
  } catch (err) {
    showToast(err.message, 'danger');
  } finally {
    btn.innerHTML = originalHtml;
    btn.disabled = false;
  }
}

// ---------------- LIVE SECURITY AUDIT SUITE ----------------
let latestSecurityAuditReport = null;

async function runLiveSecurityAudit() {
  const container = document.getElementById('security-checks-list');
  const btn = document.getElementById('run-security-audit-btn');
  const sysStatus = document.getElementById('sec-system-status');
  const scoreEl = document.getElementById('sec-score');
  const passedEl = document.getElementById('sec-passed-count');
  const durEl = document.getElementById('sec-duration');
  const timeEl = document.getElementById('sec-timestamp');
  const labelEl = document.getElementById('sec-last-run-label');
  const topBadge = document.getElementById('top-security-badge');

  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Auditing Controls...';
  }
  if (container) {
    container.innerHTML = `
      <div class="col-12 text-center py-5">
        <div class="spinner-border text-success mb-2"></div>
        <div class="small text-muted">Executing 10 live zero-trust diagnostic checks on server...</div>
      </div>
    `;
  }

  try {
    const res = await apiCall('/api/security/audit', { method: 'POST' });
    latestSecurityAuditReport = res;

    if (sysStatus) sysStatus.textContent = res.summary.system_status;
    if (scoreEl) scoreEl.textContent = `${res.summary.security_score}%`;
    if (passedEl) passedEl.textContent = res.summary.passed;
    if (durEl) durEl.textContent = `${res.summary.duration_ms} ms`;
    if (timeEl) timeEl.textContent = `Completed ${new Date(res.summary.timestamp).toLocaleTimeString()}`;
    if (labelEl) labelEl.textContent = `Last run: ${new Date(res.summary.timestamp).toLocaleTimeString()} (${res.summary.passed}/${res.summary.total_checks} passed)`;
    if (topBadge) topBadge.textContent = `${res.summary.passed}/${res.summary.total_checks} Secure`;

    if (container && res.checks) {
      container.innerHTML = res.checks.map(c => `
        <div class="col-md-6">
          <div class="p-3 tv-card h-100 border ${c.status === 'PASS' ? 'border-success' : 'border-danger'} bg-dark">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <div>
                <span class="badge ${c.status === 'PASS' ? 'bg-success-subtle text-success border border-success' : 'bg-danger'} mb-1">
                  <i class="bi ${c.status === 'PASS' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'} me-1"></i>
                  ${c.status === 'PASS' ? 'PASSED & SECURE' : 'ACTION REQUIRED'}
                </span>
                <h6 class="fw-bold mb-0 text-white">${c.title}</h6>
                <small class="text-muted" style="font-size: 0.75rem;">Category: ${c.category}</small>
              </div>
              <span class="badge bg-secondary font-monospace" style="font-size: 0.7rem;">${c.latency_ms} ms</span>
            </div>
            <p class="small text-light mb-0" style="font-size: 0.82rem; line-height: 1.4;">
              ${c.details}
            </p>
          </div>
        </div>
      `).join('');
    }

    showToast(`Security Audit Complete: ${res.summary.passed}/${res.summary.total_checks} controls verified!`, 'success');
  } catch (err) {
    if (container) {
      container.innerHTML = `<div class="col-12 alert alert-danger small">Failed to execute live security audit: ${err.message}</div>`;
    }
    showToast(err.message, 'danger');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-arrow-repeat me-1"></i> Run Security Audit';
    }
  }
}

function exportSecurityReport() {
  if (!latestSecurityAuditReport) {
    showToast('Please run the Security Audit first before exporting.', 'warning');
    return;
  }
  const blob = new Blob([JSON.stringify(latestSecurityAuditReport, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `TrustVault_Security_Audit_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Diagnostic report exported successfully.', 'info');
}

// ---------------- ADMINISTRATOR VIEWS ----------------
async function loadAdminDashboard() {
  try {
    const stats = await apiCall('/api/admin/stats');
    document.getElementById('admin-total-users').textContent = stats.total_users;
    document.getElementById('admin-active-users').textContent = stats.active_users;
    document.getElementById('admin-disabled-users').textContent = stats.disabled_users;
    document.getElementById('admin-total-docs').textContent = stats.total_documents;
    document.getElementById('admin-total-audit').textContent = stats.total_audit_events;
    
    const integrityBadge = document.getElementById('admin-audit-integrity');
    if (stats.audit_chain_valid) {
      integrityBadge.className = 'badge bg-success';
      integrityBadge.textContent = 'VALID';
    } else {
      integrityBadge.className = 'badge bg-danger';
      integrityBadge.textContent = 'COMPROMISED';
    }
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function loadUserManagement() {
  const container = document.getElementById('user-mgmt-table-body');
  container.innerHTML = '<tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const users = await apiCall('/api/admin/users');
    AppState.users = users;

    container.innerHTML = users.map(u => `
      <tr>
        <td class="fw-semibold">${u.username}</td>
        <td>${u.email}</td>
        <td>
          <span class="badge ${u.role === 'admin' ? 'badge-admin' : 'badge-owner'}">${u.role.toUpperCase()}</span>
        </td>
        <td>
          <span class="badge ${u.is_active ? 'bg-success' : 'bg-danger'}">
            ${u.is_active ? 'ACTIVE' : 'DEACTIVATED'}
          </span>
        </td>
        <td>${u.documents_count}</td>
        <td>${u.active_sessions_count}</td>
        <td class="text-end">
          ${u.id !== AppState.user.id ? `
            <button class="btn btn-sm ${u.is_active ? 'btn-outline-danger' : 'btn-outline-success'}" onclick="toggleUserStatus('${u.id}', ${!u.is_active})">
              ${u.is_active ? '<i class="bi bi-person-x"></i> Deactivate' : '<i class="bi bi-person-check"></i> Activate'}
            </button>
          ` : '<span class="badge bg-secondary">Current User</span>'}
        </td>
      </tr>
    `).join('');
  } catch (err) {
    container.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

async function toggleUserStatus(userId, newStatus) {
  try {
    await apiCall(`/api/admin/users/${userId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ is_active: newStatus }),
    });
    showToast(`Account status updated: ${newStatus ? 'Activated' : 'Deactivated'}`, 'info');
    loadUserManagement();
  } catch (err) {
    showToast(err.message, 'danger');
  }
}

async function loadSecurityActivity() {
  const container = document.getElementById('sec-activity-table-body');
  container.innerHTML = '<tr><td colspan="6" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>';

  try {
    const res = await apiCall('/api/admin/activity');
    if (res.items.length === 0) {
      container.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No security anomalies detected</td></tr>';
      return;
    }

    container.innerHTML = res.items.map(ev => `
      <tr>
        <td>
          <span class="badge ${ev.outcome === 'DENIED' ? 'badge-denied' : 'bg-warning text-dark'}">${ev.action}</span>
        </td>
        <td><small>${ev.actor_email || 'Unknown'}</small></td>
        <td><small class="badge bg-dark border">${ev.resource_type}</small></td>
        <td><small>${ev.ip_address || '—'}</small></td>
        <td><small class="text-muted">${formatDate(ev.timestamp_utc)}</small></td>
        <td>
          <button class="btn btn-sm btn-outline-info py-0 px-2" onclick="showAuditEventDetail('${ev.id}')">
            View
          </button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    container.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

// ---------------- PROFILE & SETTINGS ----------------
function loadProfile() {
  if (!AppState.user) return;
  document.getElementById('prof-username').value = AppState.user.username;
  document.getElementById('prof-email').value = AppState.user.email;
  document.getElementById('prof-role').value = AppState.user.role.toUpperCase();
  document.getElementById('prof-joined').value = formatDate(AppState.user.created_at);
}

// ---------------- PASSWORD STRENGTH METER ----------------
function updatePasswordMeter(password) {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?/~`]/.test(password)) score++;

  const fill = document.getElementById('pass-strength-fill');
  const label = document.getElementById('pass-strength-label');
  if (!fill || !label) return;

  const pct = (score / 5) * 100;
  fill.style.width = `${pct}%`;

  if (score <= 2) {
    fill.style.backgroundColor = '#ef4444';
    label.textContent = 'Weak: Include uppercase, lowercase, numbers & symbols';
    label.className = 'text-danger small mt-1';
  } else if (score <= 4) {
    fill.style.backgroundColor = '#f59e0b';
    label.textContent = 'Medium: Add special characters or increase length';
    label.className = 'text-warning small mt-1';
  } else {
    fill.style.backgroundColor = '#10b981';
    label.textContent = 'Strong password meets enterprise standards';
    label.className = 'text-success small mt-1';
  }
}

// ---------------- DOM EVENT INITIALIZATION ----------------
document.addEventListener('DOMContentLoaded', () => {
  // Check auth
  checkAuthStatus();

  // Navigation click listeners
  document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const tab = link.dataset.tab;
      if (tab) showTab(tab);
    });
  });

  // Mobile sidebar toggle
  const sidebarToggle = document.getElementById('sidebar-toggle');
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });
  }

  // Registration form password listener
  const regPassInput = document.getElementById('reg-password');
  if (regPassInput) {
    regPassInput.addEventListener('input', (e) => {
      updatePasswordMeter(e.target.value);
    });
  }

  // Login form submission
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      const btn = loginForm.querySelector('button[type="submit"]');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Authenticating...';
      btn.disabled = true;

      try {
        const res = await apiCall('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        });
        AppState.user = res.user;
        AppState.sessionToken = res.session_token;
        AppState.csrfToken = res.csrf_token;
        if (res.session_token) localStorage.setItem('tv_session_token', res.session_token);
        if (res.csrf_token) localStorage.setItem('tv_csrf_token', res.csrf_token);
        renderAppLayout();
        showTab('dashboard');
        showToast(`Welcome back, ${res.user.username}!`, 'success');
      } catch (err) {
        showToast(err.message, 'danger');
      } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
      }
    });
  }

  // Registration form submission
  const regForm = document.getElementById('register-form');
  if (regForm) {
    regForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('reg-email').value.trim();
      const username = document.getElementById('reg-username').value.trim();
      const password = document.getElementById('reg-password').value;
      const confirmPass = document.getElementById('reg-confirm-password').value;

      if (password !== confirmPass) {
        showToast('Passwords do not match', 'danger');
        return;
      }

      try {
        const res = await apiCall('/api/auth/register', {
          method: 'POST',
          body: JSON.stringify({ email, username, password }),
        });
        AppState.user = res.user;
        AppState.sessionToken = res.session_token;
        AppState.csrfToken = res.csrf_token;
        if (res.session_token) localStorage.setItem('tv_session_token', res.session_token);
        if (res.csrf_token) localStorage.setItem('tv_csrf_token', res.csrf_token);
        renderAppLayout();
        showTab('dashboard');
        showToast('Registration successful! Session established.', 'success');
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  // Logout button
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try {
        await apiCall('/api/auth/logout', { method: 'POST' });
      } catch (e) {}
      AppState.user = null;
      AppState.sessionToken = null;
      AppState.csrfToken = null;
      localStorage.removeItem('tv_session_token');
      localStorage.removeItem('tv_csrf_token');
      showAuthView('login');
      showToast('Logged out securely.', 'info');
    });
  }

  // Forgot password form
  const forgotForm = document.getElementById('forgot-form');
  if (forgotForm) {
    forgotForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('forgot-email').value.trim();
      try {
        const res = await apiCall('/api/auth/forgot-password', {
          method: 'POST',
          body: JSON.stringify({ email }),
        });
        showToast(res.message, 'info');
        if (res.reset_token) {
          document.getElementById('reset-token').value = res.reset_token;
          showAuthView('reset');
          showToast('Reset token auto-populated for verification.', 'success');
        }
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  // Reset password form
  const resetForm = document.getElementById('reset-form');
  if (resetForm) {
    resetForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = document.getElementById('reset-token').value.trim();
      const new_password = document.getElementById('reset-new-password').value;
      try {
        const res = await apiCall('/api/auth/reset-password', {
          method: 'POST',
          body: JSON.stringify({ token, new_password }),
        });
        showToast(res.message, 'success');
        showAuthView('login');
      } catch (err) {
        showToast(err.message, 'danger');
      }
    });
  }

  // Upload Form
  const uploadForm = document.getElementById('upload-form');
  const fileInput = document.getElementById('upload-file-input');
  const dropzone = document.getElementById('upload-dropzone');

  if (dropzone && fileInput) {
    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('dragover');
    });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
      if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        handleFileSelect(e.dataTransfer.files[0]);
      }
    });
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length) handleFileSelect(fileInput.files[0]);
    });
  }

  if (uploadForm) {
    uploadForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!fileInput.files.length) {
        showToast('Please select a file to upload', 'warning');
        return;
      }

      const formData = new FormData();
      formData.append('file', fileInput.files[0]);
      formData.append('title', document.getElementById('upload-title').value.trim());
      formData.append('description', document.getElementById('upload-description').value.trim());

      const progressContainer = document.getElementById('upload-progress-container');
      const progressBar = document.getElementById('upload-progress-bar');
      progressContainer.classList.remove('d-none');
      progressBar.style.width = '60%';

      try {
        const newDoc = await apiCall('/api/documents', {
          method: 'POST',
          body: formData,
        });
        progressBar.style.width = '100%';
        showToast(`Document "${newDoc.title}" uploaded and hashed securely!`, 'success');
        resetUploadForm();
        showTab('my-documents');
      } catch (err) {
        showToast(err.message, 'danger');
        progressContainer.classList.add('d-none');
      }
    });
  }

  // Grant permission form
  const grantPermForm = document.getElementById('grant-perm-form');
  if (grantPermForm) grantPermForm.addEventListener('submit', grantNewPermission);

  // Transfer ownership form
  const transferOwnerForm = document.getElementById('transfer-owner-form');
  if (transferOwnerForm) transferOwnerForm.addEventListener('submit', transferOwnership);

  // Edit metadata form
  const editDocForm = document.getElementById('edit-doc-form');
  if (editDocForm) editDocForm.addEventListener('submit', saveDocumentMetadata);

  // Search listeners
  const myDocsSearch = document.getElementById('my-docs-search');
  if (myDocsSearch) myDocsSearch.addEventListener('input', loadMyDocuments);
  const myDocsExt = document.getElementById('my-docs-ext-filter');
  if (myDocsExt) myDocsExt.addEventListener('change', loadMyDocuments);
  const auditActionFilter = document.getElementById('audit-action-filter');
  if (auditActionFilter) auditActionFilter.addEventListener('change', loadAuditHistory);
});
