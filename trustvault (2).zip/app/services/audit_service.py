"""
TrustVault Tamper-Evident Audit Service
Maintains a cryptographically linked SHA-256 hash chain for all security-relevant actions.
Detects altered, deleted, or reordered records.
"""
import hashlib
import json
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from app.models.audit_event import AuditEvent
from app.core.security import canonical_json_string

# Genesis previous hash definition (64 zeros)
GENESIS_PREVIOUS_HASH = "0" * 64

# Global lock to serialize hash-chain sequence writing in multi-threaded environments
_audit_chain_lock = threading.Lock()


def build_canonical_payload(
    sequence_number: int,
    event_id: str,
    actor_id: Optional[str],
    action: str,
    resource_type: str,
    resource_id: Optional[str],
    outcome: str,
    timestamp_utc: str,
    metadata: Dict[str, Any],
    previous_hash: str,
) -> Dict[str, Any]:
    """Build deterministic dictionary representation for cryptographic hashing."""
    return {
        "sequence_number": sequence_number,
        "event_id": event_id,
        "actor_id": actor_id or "",
        "action": action,
        "resource_type": resource_type,
        "resource_id": resource_id or "",
        "outcome": outcome,
        "timestamp_utc": timestamp_utc,
        "metadata": metadata,
        "previous_hash": previous_hash,
    }


def compute_event_hash(payload: Dict[str, Any]) -> str:
    """Compute deterministic SHA-256 hash of canonical payload."""
    canonical_str = canonical_json_string(payload)
    return hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()


class AuditService:
    @staticmethod
    def log_event(
        db: Session,
        action: str,
        resource_type: str,
        outcome: str,
        actor_id: Optional[str] = None,
        actor_email: Optional[str] = None,
        resource_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AuditEvent:
        """
        Atomically records a new tamper-evident audit event linked into the SHA-256 hash chain.
        """
        safe_meta = metadata or {}
        # Ensure no sensitive credentials ever get recorded in audit metadata
        filtered_meta = {
            k: v for k, v in safe_meta.items()
            if k.lower() not in ("password", "token", "hashed_password", "cookie", "secret", "session_token")
        }

        with _audit_chain_lock:
            # Fetch latest event in chain
            last_event = db.query(AuditEvent).order_by(desc(AuditEvent.sequence_number)).first()

            if last_event is None:
                next_seq = 1
                prev_hash = GENESIS_PREVIOUS_HASH
            else:
                next_seq = last_event.sequence_number + 1
                prev_hash = last_event.current_hash

            timestamp_str = datetime.now(timezone.utc).isoformat()
            import uuid
            event_id = str(uuid.uuid4())

            canonical_data = build_canonical_payload(
                sequence_number=next_seq,
                event_id=event_id,
                actor_id=actor_id,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                outcome=outcome,
                timestamp_utc=timestamp_str,
                metadata=filtered_meta,
                previous_hash=prev_hash,
            )

            current_hash = compute_event_hash(canonical_data)

            event = AuditEvent(
                id=event_id,
                sequence_number=next_seq,
                actor_id=actor_id,
                actor_email=actor_email,
                action=action,
                resource_type=resource_type,
                resource_id=resource_id,
                outcome=outcome,
                ip_address=ip_address,
                user_agent=user_agent,
                metadata_json=canonical_json_string(filtered_meta),
                timestamp_utc=timestamp_str,
                previous_hash=prev_hash,
                current_hash=current_hash,
            )

            db.add(event)
            db.commit()
            db.refresh(event)
            return event

    @staticmethod
    def verify_chain(db: Session) -> Dict[str, Any]:
        """
        Traverse the entire audit log from sequence 1 to latest.
        Verifies:
        1. Genesis previous_hash equals 64 zeros.
        2. Every sequence is strictly contiguous (seq = prev_seq + 1).
        3. Every previous_hash equals preceding event's current_hash.
        4. Canonical re-computation of SHA-256 matches stored current_hash exactly.
        """
        events = db.query(AuditEvent).order_by(AuditEvent.sequence_number.asc()).all()
        now_str = datetime.now(timezone.utc).isoformat()

        if not events:
            return {
                "is_valid": True,
                "total_events_verified": 0,
                "genesis_hash": GENESIS_PREVIOUS_HASH,
                "latest_hash": GENESIS_PREVIOUS_HASH,
                "broken_at_sequence": None,
                "error_detail": None,
                "verified_at": now_str,
            }

        prev_expected_hash = GENESIS_PREVIOUS_HASH
        expected_seq = 1

        for idx, event in enumerate(events):
            # Check contiguous sequence
            if event.sequence_number != expected_seq:
                return {
                    "is_valid": False,
                    "total_events_verified": idx,
                    "genesis_hash": events[0].current_hash,
                    "latest_hash": events[-1].current_hash,
                    "broken_at_sequence": event.sequence_number,
                    "error_detail": f"Sequence gap detected: expected #{expected_seq}, found #{event.sequence_number}. Possible event deletion.",
                    "verified_at": now_str,
                }

            # Check previous hash link
            if event.previous_hash != prev_expected_hash:
                return {
                    "is_valid": False,
                    "total_events_verified": idx,
                    "genesis_hash": events[0].current_hash,
                    "latest_hash": events[-1].current_hash,
                    "broken_at_sequence": event.sequence_number,
                    "error_detail": f"Broken chain link at sequence #{event.sequence_number}: previous_hash does not match preceding event's hash.",
                    "verified_at": now_str,
                }

            # Recalculate hash from canonical representation
            try:
                meta = json.loads(event.metadata_json)
            except Exception:
                meta = {}

            canonical_data = build_canonical_payload(
                sequence_number=event.sequence_number,
                event_id=event.id,
                actor_id=event.actor_id,
                action=event.action,
                resource_type=event.resource_type,
                resource_id=event.resource_id,
                outcome=event.outcome,
                timestamp_utc=event.timestamp_utc,
                metadata=meta,
                previous_hash=event.previous_hash,
            )

            computed_hash = compute_event_hash(canonical_data)
            if computed_hash != event.current_hash:
                return {
                    "is_valid": False,
                    "total_events_verified": idx,
                    "genesis_hash": events[0].current_hash,
                    "latest_hash": events[-1].current_hash,
                    "broken_at_sequence": event.sequence_number,
                    "error_detail": f"Tampered event content detected at sequence #{event.sequence_number}: computed SHA-256 hash does not match stored hash.",
                    "verified_at": now_str,
                }

            prev_expected_hash = event.current_hash
            expected_seq += 1

        return {
            "is_valid": True,
            "total_events_verified": len(events),
            "genesis_hash": events[0].current_hash,
            "latest_hash": events[-1].current_hash,
            "broken_at_sequence": None,
            "error_detail": None,
            "verified_at": now_str,
        }

    @staticmethod
    def get_events(
        db: Session,
        actor_id: Optional[str] = None,
        action: Optional[str] = None,
        resource_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Tuple[List[AuditEvent], int]:
        """Query audit log with pagination and filters."""
        query = db.query(AuditEvent)

        if actor_id:
            query = query.filter(AuditEvent.actor_id == actor_id)
        if action:
            query = query.filter(AuditEvent.action == action)
        if resource_id:
            query = query.filter(AuditEvent.resource_id == resource_id)
        if resource_type:
            query = query.filter(AuditEvent.resource_type == resource_type)

        total = query.count()
        events = query.order_by(AuditEvent.sequence_number.desc()).offset(offset).limit(limit).all()
        return events, total
