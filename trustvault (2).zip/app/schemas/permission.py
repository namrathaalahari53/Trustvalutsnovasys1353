"""
Permission schemas
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class PermissionGrantRequest(BaseModel):
    user_email: str = Field(..., pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")
    permission: str = Field(..., pattern=r"^(READ|EDIT|OWNER)$")


class PermissionUpdateRequest(BaseModel):
    permission: str = Field(..., pattern=r"^(READ|EDIT|OWNER)$")


class TransferOwnerRequest(BaseModel):
    new_owner_email: str = Field(..., pattern=r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")



class PermissionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    document_id: str
    user_id: str
    user_email: Optional[str] = None
    user_username: Optional[str] = None
    permission: str
    granted_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class PermissionListResponse(BaseModel):
    total: int
    items: List[PermissionResponse]
