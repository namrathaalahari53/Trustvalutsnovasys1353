"""
TrustVault Storage Service
Handles secure private filesystem storage, strict MIME & file signature (magic bytes) validation,
path traversal mitigation, and safe streaming.
"""
import os
import re
import uuid
import json
from pathlib import Path
from typing import Tuple, BinaryIO
from fastapi import UploadFile, HTTPException, status
from app.core.config import STORAGE_DIR, MAX_UPLOAD_SIZE_BYTES, ALLOWED_EXTENSIONS
from app.core.security import compute_sha256_bytes

# Magic bytes signatures for accepted file types
FILE_SIGNATURES = {
    "pdf": [b"%PDF-"],
    "png": [b"\x89PNG\r\n\x1a\n"],
    "jpg": [b"\xff\xd8\xff"],
    "jpeg": [b"\xff\xd8\xff"],
    "docx": [b"PK\x03\x04"],
    "xlsx": [b"PK\x03\x04"],
}


def sanitize_filename(filename: str) -> str:
    """Sanitize user-provided filename to prevent directory traversal and script injection."""
    # Normalize Windows backslashes to forward slashes
    normalized = filename.replace("\\", "/")
    # Strip any directory path components
    basename = os.path.basename(normalized)
    # Remove any null bytes or non-printable chars
    clean = re.sub(r"[^\w\.\-\s]", "_", basename).strip()
    return clean or "document"


def validate_file_content(filename: str, content: bytes) -> Tuple[bool, str, str]:
    """
    Validate file extension, size, and actual magic byte signatures.
    Returns: (is_valid, mime_type, error_message)
    """
    if not content:
        return False, "", "Uploaded file is empty (0 bytes)."

    if len(content) > MAX_UPLOAD_SIZE_BYTES:
        return False, "", f"File exceeds maximum allowed size of {MAX_UPLOAD_SIZE_BYTES // (1024*1024)} MB."

    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in ALLOWED_EXTENSIONS:
        return False, "", f"Extension '.{ext}' is not permitted. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}."

    # Validate signature if binary type
    if ext in FILE_SIGNATURES:
        signatures = FILE_SIGNATURES[ext]
        matched = any(content.startswith(sig) for sig in signatures)
        if not matched:
            return False, "", f"File signature (magic bytes) does not match expected format for .{ext}."

        mime_map = {
            "pdf": "application/pdf",
            "png": "image/png",
            "jpg": "image/jpeg",
            "jpeg": "image/jpeg",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }
        return True, mime_map.get(ext, "application/octet-stream"), ""

    # Validate plain text types (txt, md, csv, json)
    if ext in ("txt", "md", "csv"):
        # Check for null bytes which indicate binary masking
        if b"\x00" in content:
            return False, "", "Binary content or null bytes detected in text file."
        try:
            content.decode("utf-8")
        except UnicodeDecodeError:
            return False, "", "File content is not valid UTF-8 text."
        return True, "text/plain" if ext != "csv" else "text/csv", ""

    if ext == "json":
        try:
            parsed = json.loads(content.decode("utf-8"))
            if not isinstance(parsed, (dict, list)):
                return False, "", "JSON root must be an object or array."
        except Exception:
            return False, "", "File is not valid JSON."
        return True, "application/json", ""

    return False, "", "Unsupported file type."


class StorageService:
    @staticmethod
    def save_file(content: bytes) -> Tuple[str, str, int]:
        """
        Save file to private storage with a random UUID identifier.
        Returns: (storage_filename, sha256_hash, file_size)
        """
        file_hash = compute_sha256_bytes(content)
        storage_filename = f"f_{uuid.uuid4().hex}.bin"
        target_path = STORAGE_DIR / storage_filename

        # Write atomically
        temp_path = STORAGE_DIR / f"{storage_filename}.tmp"
        with open(temp_path, "wb") as f:
            f.write(content)
        temp_path.rename(target_path)

        return storage_filename, file_hash, len(content)

    @staticmethod
    def get_file_path(storage_filename: str) -> Path:
        """
        Resolve storage file path with strict path traversal verification.
        """
        # Ensure filename contains only safe alphanumeric/hex and expected prefix
        if not re.match(r"^f_[a-f0-9]{32}\.bin$", storage_filename):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid storage identifier.")

        target = (STORAGE_DIR / storage_filename).resolve()
        storage_root = STORAGE_DIR.resolve()

        if not str(target).startswith(str(storage_root)):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Path traversal attempt detected.")

        if not target.exists():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Stored file not found on disk.")

        return target

    @staticmethod
    def delete_file(storage_filename: str) -> bool:
        """Safely delete stored file."""
        try:
            path = StorageService.get_file_path(storage_filename)
            if path.exists():
                path.unlink()
            return True
        except Exception:
            return False
