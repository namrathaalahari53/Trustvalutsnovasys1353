"""
Integration tests for Documents API endpoints
"""
import io
from app.core.config import CSRF_COOKIE_NAME


def test_document_lifecycle(client):
    # Register and authenticate user
    r_reg = client.post("/api/auth/register", json={
        "email": "docowner@trustvault.local",
        "username": "docowner",
        "password": "Password#2026Doc!",
    })
    csrf = r_reg.json()["csrf_token"]

    # 1. Upload valid PDF document
    pdf_content = b"%PDF-1.4\n1 0 obj\n<< /Title (Confidential Financials) >>\nendobj\ntrailer\n<<>>\n%%EOF"
    upload_file = ("financials.pdf", io.BytesIO(pdf_content), "application/pdf")
    
    r_upload = client.post(
        "/api/documents",
        data={"title": "Q3 Financials", "description": "Highly confidential audit report"},
        files={"file": upload_file},
        headers={"X-CSRF-Token": csrf}
    )
    assert r_upload.status_code == 201
    doc_data = r_upload.json()
    doc_id = doc_data["id"]
    assert doc_data["title"] == "Q3 Financials"
    assert doc_data["is_owner"] is True
    assert len(doc_data["file_hash_sha256"]) == 64

    # 2. Get document metadata
    r_get = client.get(f"/api/documents/{doc_id}")
    assert r_get.status_code == 200
    assert r_get.json()["title"] == "Q3 Financials"

    # 3. Download document
    r_download = client.get(f"/api/documents/{doc_id}/download")
    assert r_download.status_code == 200
    assert r_download.content == pdf_content
    assert "financials.pdf" in r_download.headers.get("Content-Disposition", "")

    # 4. Update document metadata
    r_patch = client.patch(
        f"/api/documents/{doc_id}",
        json={"title": "Q3 Financials Final", "description": "Reviewed by CFO"},
        headers={"X-CSRF-Token": csrf}
    )
    assert r_patch.status_code == 200
    assert r_patch.json()["title"] == "Q3 Financials Final"

    # 5. Delete document
    r_del = client.delete(f"/api/documents/{doc_id}", headers={"X-CSRF-Token": csrf})
    assert r_del.status_code == 200

    # 6. Subsequent get must return 404
    r_after_del = client.get(f"/api/documents/{doc_id}")
    assert r_after_del.status_code == 404


def test_invalid_file_upload_rejected(client):
    r_reg = client.post("/api/auth/register", json={
        "email": "baduploader@trustvault.local",
        "username": "baduploader",
        "password": "Password#2026Bad!",
    })
    csrf = r_reg.json()["csrf_token"]

    # Empty file
    r_empty = client.post(
        "/api/documents",
        data={"title": "Empty Doc"},
        files={"file": ("empty.pdf", io.BytesIO(b""), "application/pdf")},
        headers={"X-CSRF-Token": csrf}
    )
    assert r_empty.status_code == 400
    assert "empty" in r_empty.text.lower()

    # Disallowed executable
    r_exe = client.post(
        "/api/documents",
        data={"title": "Malware"},
        files={"file": ("virus.exe", io.BytesIO(b"binarycontent"), "application/x-msdownload")},
        headers={"X-CSRF-Token": csrf}
    )
    assert r_exe.status_code == 400
    assert "not permitted" in r_exe.text.lower()
